import datetime
import random
import matplotlib.dates as mdates
import matplotlib.pyplot as plt

import matplotlib.pyplot as plt
import numpy as np


from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.row_event import DeleteRowsEvent,WriteRowsEvent,UpdateRowsEvent
from pymysqlreplication.event import GtidEvent,QueryEvent
import time
import timeout_decorator
import pymysql



class event():

    def __init__(self,action,table_name,rows):
        self.action = action
        self.table_name = table_name
        self.rows = rows
        self.times = 0


MYSQL_SETTINGS = {
    'host' : '10.0.10.60',
    'user' : 'weixinping',
    'password' : '$X2EGrRt',
    'port':35972
}

a = "2013-10-10 23:40:00"
import time
timeArray = time.strptime('2019-12-17 8:00:00', "%Y-%m-%d %H:%M:%S")
start_time = int(time.mktime(timeArray))
stop_time = int(time.mktime(time.strptime('2019-12-17 9:00:00', "%Y-%m-%d %H:%M:%S")))

x = []
y = []
action_dic = {}
schemas = set()
stream = BinLogStreamReader(
    connection_settings=MYSQL_SETTINGS,
    server_id=3,
    blocking=False,
    #only_schemas=['zxxd_credit_report'],
    #only_tables=['rhzx_outside_value_compare'],
    only_events=[DeleteRowsEvent, WriteRowsEvent, UpdateRowsEvent],
    log_file='bin-log.000032',
    log_pos=4
)
try:
    for binlogevent in stream:

        #table_name = f'{binlogevent.schema}.{binlogevent.table}'
        #rows = len(binlogevent.rows)
        #print(binlogevent.schema)
        if binlogevent.timestamp < start_time :
            continue

        if binlogevent.timestamp > stop_time :
            break

        #print('update', binlogevent.table, time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(binlogevent.timestamp)))
        table_name = binlogevent.table
        rows = len(binlogevent.rows)

        if datetime.datetime.fromtimestamp(binlogevent.timestamp) not in action_dic.keys():
            action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)] = rows
        else:
            action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)] += rows

finally:
    stream.close()

print(action_dic)

name_list = []
num_list = []

for item in action_dic.items():
    #print(item)
    name_list.append(item[0])
    num_list.append(item[1])
# make up some data
x = name_list
y = num_list

#print(x)
# plot
x.sort()

plt.xlim(x[0],x[-1])
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
# beautify the x-labels
plt.scatter(x,y)
plt.gcf().autofmt_xdate()

plt.show()