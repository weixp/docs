import redis
key_pattern = 'USERCENTER:TOKEN:MAP*'
r = redis.StrictRedis(host = "172.17.100.16",port = 6379)
cursor,data = r.scan(match=key_pattern,count=10000)
i = 0
while cursor != 0:
    print(len(data))
    i = i + len(data)
    cursor, data = r.scan(match=key_pattern,cursor=cursor, count=10000)
print(i)