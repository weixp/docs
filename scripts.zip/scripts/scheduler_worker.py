#!/usr/local/bin/python3
import os
from datetime import datetime
import time
from concurrent.futures import ProcessPoolExecutor
import netifaces
import croniter
import subprocess
import shlex
import traceback
import logging
import pymysql
from email.mime.text import MIMEText
from email.utils import formataddr
import smtplib
from DBUtils.PooledDB import PooledDB

#连接配置库用的
config_db_host = '172.16.100.36'
config_db_user = 'yunwei'
config_db_pwd = '7PMbpSGtFi'
config_db_port = 35972

#配置日志
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s  %(levelname)s  %(message)s',
                    datefmt='[%d/%b/%Y %H:%M:%S]',
                    filename='/tmp/scheduler_worker.log')

POOL = PooledDB(
    creator=pymysql,
    maxconnections=6,
    mincached=2,
    maxcached=2,
    maxshared=2,
    blocking=False,
    maxusage=None,
    setsession=[],
    ping=0,# ping MySQL服务端，检查是否服务可用。# 如：0 = None = never, 1 = default = whenever it is requested, 2 = when a cursor is created, 4 = when a query is executed, 7 = always
    host=config_db_host,
    port=config_db_port,
    user=config_db_user,
    password=config_db_pwd,
    database='yandi',
    charset='utf8',
    cursorclass=pymysql.cursors.DictCursor
)

#单个定时任务类
class Job():

    def __init__(self,cron_dic):
        self.job_id = cron_dic['id']
        self.cron = cron_dic['cron']
        self.command = cron_dic['command']
        self.last_run = cron_dic['last_run']
        self.one_time = cron_dic['one_time']
        self.enabled = cron_dic['enabled']
        self.deleted = cron_dic['deleted']
        self.futures = None

    def update(self,cron_dic):
        self.cron = cron_dic['cron']
        self.command = cron_dic['command']
        self.one_time = cron_dic['one_time']
        self.enabled = cron_dic['enabled']
        self.deleted = cron_dic['deleted']

    def get_next_run(self):

        if not self.enabled :
            return  False

        if self.deleted:
            return False

        next_run = croniter.croniter(self.cron, self.last_run or datetime.now()).get_next(datetime)
        #print(next_run)
        #print(self.command)
        if next_run < datetime.now():
            self.last_run = datetime.now()
            return True
        else:
            return False


    def get_job(self):
        return {
            'command':self.command,
            'id':self.job_id,
            'last_run':self.last_run

        }


configs = None
#跳转到脚本所在地
os.chdir('/app/scripts')

#获取本地ip
interface = 'bond0' if 'bond0' in netifaces.interfaces() else 'eth0'
host = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['addr']
logging.info(f'{host} is about to go to work\n')
#host = '127.0.0.1'

#获取配置
con = None
try:
    con = POOL.connection()
    cursor = con.cursor()
    cursor.execute(f'select * from yandi.config_all a,yandi.config_single s where s.`host` = "{host}"')
    configs = cursor.fetchone()
except Exception as e:
    traceback.print_exc()
    logging.error(traceback.format_exc())
    raise
finally:
    if con is not None:
        con.close()

#print(configs)

def run_job(job):
    output = ''
    results = {}
    #正式执行任务
    try:
        complete = subprocess.run(shlex.split(job['command']),
                                  stderr=subprocess.PIPE,
                                  stdout=subprocess.PIPE,
                                  encoding='utf-8',
                                  env=os.environ)

        output,successful = (complete.stdout,True) if complete.returncode == 0 else (complete.stderr,False)
        results['successful'] = successful
        results['output'] = output

    except Exception:

        results['successful'] = False
        results['output'] = traceback.print_exc()
        #发送失败邮件
    finally:
        results['stop_time'] = datetime.now()
        return results

#print(configs['workers'])
with ProcessPoolExecutor(max_workers=configs['workers']) as executor:
    crontabs_raw = []
    crontabs = {}
    crontabs_raw_ids = []
    while True:
        # 获取定时任务
        try:
            crontabs_raw_ids = []
            con = POOL.connection()
            cursor = con.cursor()
            cursor.execute(f'select * from yandi.crontab where ip="{host}" ')
            crontabs_raw = cursor.fetchall()
            for crontab_raw in crontabs_raw:

                crontabs_raw_ids.append(crontab_raw['id'])

                if crontab_raw['id'] not in crontabs.keys():
                    crontabs[crontab_raw['id']]= Job(crontab_raw)
                else:
                    crontabs[crontab_raw['id']].update(crontab_raw)

            #还有处理一种情况就是从数据库里面查的时候，已经没有了，那需要从缓存里删掉
            for id in crontabs.keys():
                if id not in crontabs_raw_ids:
                    crontabs.pop(id)

        except Exception as e:
            traceback.print_exc()
            logging.error(traceback.format_exc())
        finally:
            if con is not None:
                con.close()

        # 判断是否要执行，如果要执行，那就执行
        for crontab in  crontabs.values():

            if crontab.futures is not None:
                if crontab.futures.done():
                    try:
                        results = crontab.futures.result()
                        #print(results)
                        con = POOL.connection()
                        cursor = con.cursor()

                        #如果是一次性的，需要停止掉这个任务
                        if crontab.one_time:
                            cursor.execute(f"update yandi.crontab set enabled=false where id={crontab.job_id}")

                        if results['successful']:
                            cursor.execute(f"update yandi.crontab set success=success+1,last_run='{crontab.last_run}' where id={crontab.job_id}")
                        else:
                            cursor.execute(f"update yandi.crontab set failed=failed+1 ,last_run='{crontab.last_run}' where id={crontab.job_id}")
                            #发送失败原因邮件
                            my_sender = 'idc@treefintech.com'  # 发件人邮箱账号
                            my_pass = 'W0@Mail.ds'  # 发件人邮箱密码(当时申请smtp给的口令)
                            my_user = ['weixinping@treefintech.com', ]  # 收件人邮箱账号，我这边发送给自己
                            msg = MIMEText(f'{host}定时任务{crontab.command}出错:' + results['output'], 'plain', 'utf-8')
                            msg['From'] = formataddr(["DBA定时任务系统", my_sender])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
                            msg['To'] = formataddr(["大树金科DBA", ','.join(my_user)])  # 括号里的对应收件人邮箱昵称、收件人邮箱账号
                            msg['Subject'] = '定时任务系统'  # 邮件的主题，也可以说是标题
                            server = smtplib.SMTP_SSL("smtp.exmail.qq.com", 465)  # 发件人邮箱中的SMTP服务器，端口是465
                            server.login(my_sender, my_pass)  # 括号中对应的是发件人邮箱账号、邮箱密码
                            server.sendmail(my_sender, my_user, msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
                            server.quit()

                        cursor.execute(f"insert into yandi.crontab_result(job_id,success,output,start_time,stop_time) values(%s,%s,%s,%s,%s)",
                            (crontab.job_id,
                             results['successful'],
                             results['output'],
                             crontab.last_run,
                             results['stop_time']))

                        cursor.execute('commit')

                    except Exception :
                        traceback.print_exc()
                        logging.error(traceback.format_exc())
                    finally:
                        crontab.futures = None
                        con.close()
                else:
                    continue

            if crontab.get_next_run() :
                crontab.futures = executor.submit(run_job,crontab.get_job())

        #沉睡60s
        print('sleepping 60s')
        time.sleep(60)