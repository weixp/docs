#!/usr/local/bin/python3
# 该脚本负责删除从库的relaylog 和 binlogserver的binlog
#relay-log=/app/mysql/log/relay/relay-log
import argparse
import os
import datetime
import sys, logging

logging.basicConfig(level=logging.INFO,
format='levelname:%(levelname)s filename: %(filename)s '
'outputNumber: [%(lineno)d] thread: %(threadName)s output msg: %(message)s'
' - %(asctime)s', datefmt='[%d/%b/%Y %H:%M:%S]',
filename='/var/log/mysql_log_clear.log')

logging.info("start log clear")

replay_log_path = '/app/mysql/log/relay/'
replay_prefix = 'replay-log'
binlog_server_path = '/backup/current_master_binlog'
binlog_prefix = 'bin-log'

parser = argparse.ArgumentParser(usage="it's usage tip.", description="help info.")
parser.add_argument("--rkeep", help="the day relay log keep", default="5" ,dest="rkeep")
parser.add_argument("--bkeep", help="the day binlogserver log keep", default="5" ,dest="bkeep")
args = parser.parse_args()
rkeep = args.rkeep
bkeep = args.bkeep

#删除relaylog
if os.path.exists(replay_log_path):
    os.chdir(replay_log_path)
    filenames = os.listdir(replay_log_path)
    filenames.remove('relay-log.index')
    for filename in filenames:
        t_time = os.path.getmtime(filename)
        if (datetime.datetime.now() - datetime.timedelta(days=int(rkeep))) > datetime.datetime.fromtimestamp(t_time) :
            if filename.startswith('relay-log'):
                os.remove(filename)
                logging.info("file %s removed" % filename)
        else:
            print('文件挺新鲜，不需要删除')
#删除binlogserver的binlog
if os.path.exists(binlog_server_path):
    os.chdir(binlog_server_path)
    filenames = os.listdir(binlog_server_path)
    for filename in filenames:
        t_time = os.path.getmtime(filename)
        if (datetime.datetime.now() - datetime.timedelta(days=int(rkeep))) > datetime.datetime.fromtimestamp(t_time) :
            if filename.startswith('bin-log'):
                os.remove(filename)
                logging.info("file %s removed" % filename)
        else:
            print('文件挺新鲜，不需要删除')

logging.info("log file removed finished")