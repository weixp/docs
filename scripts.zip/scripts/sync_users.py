import mysql
#先从所有生产库当中获取用户名
import pymysql

vips = [
    '172.16.100.203',
    '172.16.100.204',
    '172.16.100.205',
    '172.16.14.253',
    '172.17.100.203',
    '172.17.100.204'
]

product_users = []
config_users = []

config_con = pymysql.connect(host='172.16.100.36', user='weixinping', password='$X2EGrRt', port=35972, charset='utf8',cursorclass=pymysql.cursors.DictCursor)
config_cursor = config_con.cursor()
get_config_user_sql = """select * from yandi.mysql_user"""
config_cursor.execute(get_config_user_sql)
config_results =  config_cursor.fetchall()

for config_user in config_results:
    config_users.append(config_user['mysql_name'])

print(config_users)

get_user_sql = """select user from mysql.user t where t.`User` not in ('admin','mysql.session','mysql.sys')"""
for vip in vips:
    con = pymysql.connect(host=vip, user='weixinping', password='$X2EGrRt', port=35972, charset='utf8',cursorclass=pymysql.cursors.DictCursor)
    cursor = con.cursor()
    cursor.execute(get_user_sql)
    results = cursor.fetchall()
    con.close()
    for user in results:
        if user['user'] not in product_users and user['user'] not in config_users:
            print("""insert into yandi.mysql_user(name,role,mysql_name,mysql_password) values('','其他','{0}',null)""".format(user['user']))
            insert_sql = """insert into yandi.mysql_user(name,role,mysql_name,mysql_password) values('','其他','{0}',null)""".format(user['user'])
            product_users.append(user['user'])
            config_cursor.execute(insert_sql)
            config_cursor.execute('commit')

#print(users)
#print(len(users))
#获取配置库的mysql用户信息
config_con.close()


