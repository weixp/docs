#获取全生产环境数据库表大小的脚本
import pymysql


db_user = 'yunwei'
db_pwd = '7PMbpSGtFi'
db_port = 35972

#数据库主库ip
ip_list = ['172.17.100.24',
           '172.17.100.26',
           '172.17.100.27',
           '172.17.100.28',
           '172.17.100.30',
           '172.17.100.37',
           '172.17.100.100'
           ]

tables_size = ()

for ip in ip_list:
    print(ip)
    con = pymysql.connect(ip,
                          db_user,
                          db_pwd,
                          port=db_port)
    try:
        with con.cursor() as cursor:
                cursor.execute(f"""SELECT
                                                t.TABLE_SCHEMA,
                                                t.table_name,
                                                sum(t.DATA_LENGTH + t.INDEX_LENGTH) size,
                                                t.TABLE_ROWS,
                                                '{ip}' vip
                                            FROM
                                                information_schema.`TABLES` t
                                            WHERE
                                                TABLE_SCHEMA NOT IN (
                                                    'sys',
                                                    'information_schema',
                                                    'mysql',
                                                    'performance_schema'
                                                )
                                            GROUP BY
                                                t.TABLE_SCHEMA,
                                                t.TABLE_NAME
                                        """)
        #print(cursor.fetchall())
        tables_size = tables_size + cursor.fetchall()
    finally:
            con.close()

print(len(tables_size))
#把表的大小分批插入到数据库当中
con = pymysql.connect('172.17.100.37',
                      db_user,
                      db_pwd,
                      port=db_port)
try:
    with con.cursor() as cursor:
        cursor.executemany("""insert into yandi.tables_size(db_name,table_name,table_size,table_rows,vip) values(%s,%s,%s,%s,%s)""",tables_size)
        con.commit()
finally:
    con.close()
