import redis
con = redis.Redis(host='172.17.100.36', port=6379, db=0)
f = open('get_delay.py','r')

f.seek(25)
a = f.readline()
print(a)
f.close()