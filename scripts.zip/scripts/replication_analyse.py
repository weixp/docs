from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.row_event import DeleteRowsEvent,WriteRowsEvent,UpdateRowsEvent
import time
import timeout_decorator

class event():

    def __init__(self,action,table_name,rows):
        self.action = action
        self.table_name = table_name
        self.rows = rows
        self.times = 0



MYSQL_SETTINGS = {
    'host' : '172.17.100.28',
    'user' : 'weixinping',
    'password' : '$X2EGrRt',
    'port':35972
}

action_dic = {}



@timeout_decorator.timeout(3)
def main():
    try:
        stream = BinLogStreamReader(
            connection_settings=MYSQL_SETTINGS,
            server_id=3,
            blocking=True,
            #only_schemas=["jintui"],
            #only_events=[DeleteRowsEvent, WriteRowsEvent, UpdateRowsEvent]
            log_file='bin-log.003601',
            log_pos=274
        )
        for binlogevent in stream:
            for row in binlogevent.rows:
                event = {"schema": binlogevent.schema, "table": binlogevent.table}
                if isinstance(binlogevent, DeleteRowsEvent):
                    table_name = f'{binlogevent.schema}.{binlogevent.table}'
                    rows = len(binlogevent.rows)
                    if table_name in action_dic.keys():
                        action_dic[table_name]['delete'] +=  rows
                        action_dic[table_name]['times'] += 1
                    else:
                        action_dic[table_name] = {'delete':rows,'update':0,'insert':0,'times':1}
                elif isinstance(binlogevent, UpdateRowsEvent):
                    table_name = f'{binlogevent.schema}.{binlogevent.table}'
                    rows = len(binlogevent.rows)
                    if table_name in action_dic.keys():
                        action_dic[table_name]['update'] +=  rows
                        action_dic[table_name]['times'] += 1
                    else:
                        action_dic[table_name] = {'delete': 0, 'update': rows, 'insert': 0,'times':1}
                elif isinstance(binlogevent, WriteRowsEvent):
                    table_name = f'{binlogevent.schema}.{binlogevent.table}'
                    rows = len(binlogevent.rows)
                    if table_name in action_dic.keys():
                        action_dic[table_name]['insert'] +=  rows
                        action_dic[table_name]['times'] += 1
                    else:
                        action_dic[table_name] = {'delete': 0, 'update': 0, 'insert': rows,'times':1}

    except timeout_decorator.timeout_decorator.TimeoutError as e:
        for key,value in action_dic.items():
            print(key,value)
    finally:
        stream.close()

if __name__ == "__main__":
    main()