from ZabbixSender import ZabbixSender, ZabbixPacket
# !/usr/local/bin/python3
import pymysql
import psutil
import  logging
import traceback
import argparse

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s  %(levelname)s  %(message)s',
    datefmt='[%d/%b/%Y %H:%M:%S]',
    filename='/tmp/mysql_monitor.log')


port = 35972
user = 'yunwei'
password = '7PMbpSGtFi'
net_device = 'bond0'

parser = argparse.ArgumentParser(description = 'this is a description')
parser.add_argument('--destination', '-d', help = 'the ip of zabbix_server')
parser.add_argument('--source', '-s', help = 'the ip of local server')
# 将变量以标签-值的字典形式存入args字典
args = parser.parse_args()

host = args.source


wanted_keys = [
                   #连接数监控
                   "Aborted_clients",
                   "Aborted_connects",
                   "Threads_cached",
                   "Threads_connected",
                   "Threads_created",
                   "Threads_running",
                   "Connections",
                   "max_connections",

                   #binlog相关监控
                   "Binlog_cache_disk_use",
                   "Binlog_cache_use",

                   #mysql进出流量监控
                   "Bytes_received",
                   "Bytes_sent",

                   #mysql操作命令数量监控
                   "Queries",
                   "Questions",
                   "Com_commit",
                   "Com_delete",
                   "Com_delete_multi",
                   "Com_insert",
                   "Com_insert_select",
                   "Com_rollback",
                   "Com_select",
                   "Com_update",
                   "Com_update_multi",

                   ##慢日志数量监控
                   "Slow_queries",

                   #零时表创建监控
                   "Created_tmp_disk_tables",
                   "Created_tmp_files",
                   "Created_tmp_tables",

                   #innodb 脏数据比例
                   "Innodb_buffer_pool_bytes_data",
                   "Innodb_buffer_pool_bytes_dirty",

                   #innodb命中率监控
                   "Innodb_buffer_pool_read_requests",#读的总请求数
                   "Innodb_buffer_pool_reads",#读物理文件的总请求数

                   #可以根据反应磁盘的性能是否是瓶紧，这个是实时值
                   "Innodb_log_waits",
                   "Innodb_data_pending_fsyncs",
                   "Innodb_data_pending_reads",
                   "Innodb_data_pending_writes",
                   "Innodb_os_log_pending_fsyncs",
                   "Innodb_os_log_pending_writes",

                   #innodb锁监控
                   "Innodb_row_lock_current_waits",
                   "Innodb_row_lock_waits",

                   #innodb实际影响行数监控
                   "Innodb_rows_deleted",
                   "Innodb_rows_inserted",
                   "Innodb_rows_read",
                   "Innodb_rows_updated",

                   #表打开监控
                   "Open_files",
                   "Open_table_definitions",
                   "Open_tables",
                   "Opened_table_definitions",
                   "Opened_tables",

                   #从库监控
                   "SQL_Delay",
                   "Seconds_Behind_Master",
                   "Slave_IO_Running",
                   "Slave_SQL_Running",

                   #观察数据库常用执行计划
                   "Select_full_join",
                   "Select_full_range_join",
                   "Select_range",
                   "Select_range_check",
                   "Select_scan",
                   "Sort_merge_passes",
                   "Sort_range",
                   "Sort_scan",

                   "Uptime",
                   "instance_size",
                   "read_only"
                   ]

# 查看本地mysql是否存在
try:
    names = []
    for proc in psutil.process_iter():
        pinfo = proc.as_dict(attrs=['name'])
        names.append(pinfo['name'])

    if 'mysqld' in names:
        # 发送所有值
        server = ZabbixSender(args.destination, 10051)
        packet = ZabbixPacket()
        packet.add(host, 'alive_status', '1')
        con = pymysql.connect(host, user, password, port=port, cursorclass=pymysql.cursors.DictCursor,
                              charset='utf8')
        cursor = con.cursor()
        # 处理status的值
        cursor.execute('show global status')
        results = cursor.fetchall()
        for result in results:

            if result['Variable_name'] in wanted_keys:
                #print(result)
                packet.add(host, result['Variable_name'], result['Value'])

        # 处理实例大小的值
        cursor.execute(
            "select sum(DATA_LENGTH+INDEX_LENGTH) instance_size from information_schema.`TABLES` where table_schema not in ('sys') ")
        packet.add(host, 'instance_size', cursor.fetchone()['instance_size'])


        #处理slave的值,先要查看是不是slave
        cursor.execute('show slave status')
        results = cursor.fetchone()
        if results is not None:
            packet.add(host, 'role', 'slave')
            for item,value in results.items():

                if item == 'Seconds_Behind_Master' and value is None:
                    #print(item, value)
                    continue
                if item in wanted_keys:
                    packet.add(host, item, value)
        else:
            packet.add(host, 'role', 'master')

        #处理variables的
        cursor.execute('show global variables')
        results = cursor.fetchall()
        for result in results:

            if result['Variable_name'] in wanted_keys:
                #print(result)
                packet.add(host, result['Variable_name'], result['Value'])
        server.send(packet)
        #print(packet)
        logging.info(server.status)
        con.close()


    elif 'mysqld' not in names:
        # 只发送ping的值
        server = ZabbixSender(args.destination, 10051)
        packet = ZabbixPacket()
        packet.add(host, 'alive_status', '0')
        # 先放status的值

        server.send(packet)
        logging.info(server.status)
        #print(server.status)
except  Exception as e:
    logging.error(traceback.format_exc())

