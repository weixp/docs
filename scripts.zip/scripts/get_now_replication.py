from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.row_event import DeleteRowsEvent,WriteRowsEvent,UpdateRowsEvent
from pymysqlreplication.event import GtidEvent,QueryEvent
import time
import timeout_decorator
import pymysql

class event():

    def __init__(self,action,table_name,rows):
        self.action = action
        self.table_name = table_name
        self.rows = rows
        self.times = 0


MYSQL_SETTINGS = {
    'host' : '10.0.10.60',
    'user' : 'weixinping',
    'password' : '$X2EGrRt',
    'port':35972
}

slave_settings = {
    'host' : '10.0.10.62',
    'user' : 'weixinping',
    'password' : '$X2EGrRt',
    'port':35972,
    'cursorclass':pymysql.cursors.DictCursor
}

action_dic = {}

'Relay_Master_Log_File'
'Exec_Master_Log_Pos'
update_file = 'update_sql.sql'
file = open(update_file,'w')
#获取从库相对于主库执行的位置
con = pymysql.connect(**slave_settings)
try:
    with con.cursor() as cursor:
        cursor.execute('show slave status')
        results = cursor.fetchone()
        Relay_Master_Log_File = results['Relay_Master_Log_File']
        Exec_Master_Log_Pos = results['Exec_Master_Log_Pos']
finally:
    con.close()


def main():
    try:
        stream = BinLogStreamReader(
            connection_settings=MYSQL_SETTINGS,
            server_id=4,
            blocking=False,
            #only_schemas=['mysql'],
            only_events=[DeleteRowsEvent,WriteRowsEvent,UpdateRowsEvent],
            log_file=Relay_Master_Log_File,
            log_pos=Exec_Master_Log_Pos
        )
        i = 0
        for binlogevent in stream:

            if isinstance(binlogevent,GtidEvent):
                print(binlogevent)
            elif isinstance(binlogevent, UpdateRowsEvent):
                table_name = f'{binlogevent.schema}.{binlogevent.table}'
                rows = len(binlogevent.rows)
                print('update',table_name,rows,time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(binlogevent.timestamp)) )
                file.write('update '+ table_name + ' '+str(rows) + ' ' + time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(binlogevent.timestamp))+'\n')
                exit()

            elif isinstance(binlogevent, WriteRowsEvent):
                table_name = f'{binlogevent.schema}.{binlogevent.table}'
                rows = len(binlogevent.rows)
                print('insert',table_name,rows,time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(binlogevent.timestamp)))
                file.write('insert ' + table_name+ ' ' + str(rows) + ' ' + time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(binlogevent.timestamp))+'\n')
                exit()

            elif isinstance(binlogevent, DeleteRowsEvent):
                table_name = f'{binlogevent.schema}.{binlogevent.table}'
                rows = len(binlogevent.rows)
                print('delete',table_name,rows,' rows',time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(binlogevent.timestamp)))
                exit()
                file.write('delete ' + table_name+ ' ' + str(rows) + ' ' + time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(binlogevent.timestamp))+'\n')

            else:
                print(binlogevent)

        file.flush()
        file.close()

    except timeout_decorator.timeout_decorator.TimeoutError as e:
        for key,value in action_dic.items():
            print(key,value)
    finally:
        stream.close()

if __name__ == "__main__":
    main()

#也就是说按照这个去拿的话，会获取上一个gtid后面的值


#10:27:48