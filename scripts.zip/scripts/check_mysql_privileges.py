#用于检查自己的生产库权限,端口都是35972
import pymysql
user = 'weixinping'
b = 0-len(user)-10
pwd = '$X2EGrRt'

#这里最后的连接ip'172.17.100.100'如果连接不上，可以试试看10.0.10.60。或者相反。这个ip下面是中新环境的库
dashu_ip_list = ['172.17.100.24',
                 '172.17.100.26',
                 '172.17.100.27',
                 '172.17.100.28',
                 '172.17.100.30',
                 '172.17.100.37',
                 '10.0.10.60']


for ip in dashu_ip_list:
    print(f'下面的库请用这个ip连接{ip}')
    try:
        con = pymysql.connect(ip,user,pwd,port=35972)
        try:
            with  con.cursor() as cursor:
                cursor.execute(f"create user data_biz identified by 'Data@123' ")
                cursor.execute('grant select on *.* to data_biz')
        finally:
            con.close()
    except pymysql.err.OperationalError as e:
        print(e)


