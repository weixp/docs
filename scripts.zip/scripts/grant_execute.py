import traceback
import time
import subprocess
import pymysql
import json
from email.mime.text import MIMEText
from email.utils import formataddr
import smtplib
import random

def send_email(content,email=''):

    my_sender = 'idc@treefintech.com'  # 发件人邮箱账号
    my_pass = 'W0@Mail.ds'  # 发件人邮箱密码(当时申请smtp给的口令)
    my_user = [email,'dba@treefinance.com.cn']  # 收件人邮箱账号，我这边发送给自己

    if email == '':
        my_user.remove('')

    msg = MIMEText(content, 'plain', 'utf-8')
    msg['From'] = formataddr(["大树金科DBA", my_sender])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
    msg['To'] = formataddr(["大树金科员工", ','.join(my_user)])  # 括号里的对应收件人邮箱昵称、收件人邮箱账号
    msg['Subject'] = '数据修改工单执行结果'  # 邮件的主题，也可以说是标题
    server = smtplib.SMTP_SSL("smtp.exmail.qq.com", 465)  # 发件人邮箱中的SMTP服务器，端口是465
    server.login(my_sender, my_pass)  # 括号中对应的是发件人邮箱账号、邮箱密码
    server.sendmail(my_sender, my_user, msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
    server.quit()

def click_gongdan(id):
    from selenium import webdriver
    try:
        chrome_options = webdriver.ChromeOptions()
        chrome_options.binary_location='/usr/bin/google-chrome'
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--disable-dev-shm-usage')
        driver = webdriver.Chrome('/usr/bin/chromedriver',chrome_options=chrome_options)
        driver.get('http://172.16.14.197:1338/processOper')
        driver.find_element_by_id('identifier').send_keys('魏新平')
        driver.find_element_by_id('password').send_keys('wxp@772008')
        driver.find_element_by_xpath('/html/body/div[2]/div/section/div[2]/form/button').click()
        time.sleep(3)
        gongdan_index = 1
        for i in driver.find_elements_by_xpath('//*[@id="table-flow"]/tbody/tr'):
            if i.text.split()[0] == 'No':
                driver.quit()
                #print('当前没有工单可以点击')
                continue
            if int(i.text.split()[0]) == id :
                driver.find_element_by_xpath('//*[@id="table-flow"]/tbody/tr[{0}]/td[7]/a'.format(gongdan_index)).click()
                time.sleep(3)
                driver.find_element_by_xpath('//*[@id="id_buttons"]/button[4]').click()
                time.sleep(2)
                driver.find_element_by_xpath('/html/body/div[4]/div/div/div[3]/button[2]').click()
                #print('%s号工单已经通过' % (i.text.split()[0]))
                time.sleep(3)
                driver.quit()
                break
            gongdan_index = gongdan_index + 1
    except :
        traceback.print_exc()
    finally:
        subprocess.run('pkill chrome',shell=True)

subject = '发布系统sql执行结果提醒'
# 处理授权工单

get_gd_sql = '''
SELECT
    t.Id id,
    t.Discribe db,
    u.email email,
    d.name department
FROM
    publish.t_process_info t,
    publish.`USER` u,
    publish.department d
WHERE
    t.Applicant = u.id
AND t.type = 3
AND u.isactive = 1
and u.department = d.id
and t.status = 5
and t.id not in (select executed_id from publish.executed_gd)
limit 1
'''

config_db_ip = '172.16.100.36'
user = 'yunwei'
passwd = '7PMbpSGtFi'

vip_dic = {
'172.16.100.203':'172.16.100.26:35972',
'172.16.100.204':'172.16.100.30:35972',
'172.16.100.205':'172.16.100.32:35972',
'172.17.100.203':'172.17.100.26:35972',
'172.17.100.204':'172.17.100.30:35972',
'172.17.100.100':'172.17.100.100:35972',
'172.17.200.254':'172.17.200.254:54000'
}

gd = None

#获取工单信息，这里只获取单个工单进行处理
con = pymysql.connect('172.16.14.253',user,passwd,port=35972,cursorclass=pymysql.cursors.DictCursor,charset='utf8')
try:
    with con.cursor() as cursor:
        cursor.execute(get_gd_sql)
        if cursor.rowcount <= 0:
            exit()
        else:
            gd = cursor.fetchone()
            cursor.execute(f'''insert into publish.executed_gd(executed_id) values({gd['id']})''')
            con.commit()
finally:
    con.close()

id = gd['id']
email = gd['email']
mysql_name = email.split('@')[0]
department = gd['department']
db_info = json.loads(gd['db'])['data']
content = '您的授权工单id已经处理好了。\n'
password = None
is_vpn_user = True if department in ('CEO-数模分析部','CEO-CRO-策略中心-风控部','CEO-数模分析部') else False
is_new_user = False

if is_vpn_user:
    #获取配置数据库当中用户的密码，没有就创建
    con = pymysql.connect(config_db_ip, user, passwd, port=35972)
    try:
        with con.cursor() as cursor:
            cursor.execute(f'select mysql_password from yandi.mysql_user where mysql_name = "{mysql_name}" ')
            if cursor.rowcount ==1:
                password = cursor.fetchone()[0]
            #如果密码不存在那就创建新密码，然后插入配置数据库当中
            if password is None:
                is_new_user = True
                password = ''
                code = '''abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ123456789!@#%&()*"{}'''
                for i in range(10):
                    j = random.randint(0, len(code) - 1)
                    password += code[j]
                cursor.execute(f"insert into yandi.mysql_user(mysql_name,mysql_password) values(%s,%s)",(mysql_name,password))
                con.commit()
    finally:
        con.close()

#判断用户是否是拥有vpn的，如果有就真正授权，如果没有，就直接点击完成，不进行实际授权
if is_vpn_user:
    for db in db_info:

        vip = db['datasource'].split('|')[2]
        db_name = db['datasource'].split('|')[1]
        tables = db['table']

        content = content + f"""
        '{db_name}'的连接方式为'{vip_dic[vip]}'
        """

        if vip == '172.17.200.254':
            port = 54000
        else:
            port = 35972

        #正式赋权
        con = pymysql.connect(vip,user,passwd,port=port)
        try:
            with con.cursor() as cursor:
                print(vip)
                cursor.execute(f"CREATE USER IF NOT EXISTS '{mysql_name}'@'%' IDENTIFIED BY '{password}'")
                for table in tables:
                    if table == 'all':
                        cursor.execute(f"grant select on `{db_name}`.* to {mysql_name}")
                        #print(f"grant select on `{db_name}`.* to {mysql_name}")
                    else:
                        cursor.execute(f"grant select on `{db_name}`.`{table}` to {mysql_name}")
                        #print(f"grant select on `{db_name}`.`{table}` to {mysql_name}")
        finally:
            con.close()
    if is_new_user:
        content = f'你是新用户，数据库密码为{password}\n'+content
    send_email(content,email=email)

click_gongdan(id)