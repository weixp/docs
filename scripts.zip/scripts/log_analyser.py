# -*- coding: utf-8 -*-
import os
import traceback
import shlex
import subprocess
import time
from datetime import datetime
from utilities import get_host,get_config,query

#获取配置信息
host = get_host()
config = get_config(host=host)
get_max_time_sql = f"select max(starttime) max_time from yandi.proxysql_logs where server = '{host}:35972'"

max_time = query(get_max_time_sql)

if len(max_time) == 0:
    max_time = None
else:
    max_time = max_time[0]['max_time']
    max_timestamp = time.mktime(max_time.timetuple())

os.chdir('/var/lib/proxysql')



for file in os.listdir('/var/lib/proxysql'):

    if file.startswith('queries.log.') :
        m_time = os.stat(file).st_mtime
        if max_time is not None and m_time <max_timestamp:
            continue
        cmd = shlex.split(f'/usr/share/proxysql/proxysql-1.4.4/tools/eventslog_reader_sample {file}')
        p = subprocess.Popen(cmd, shell=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        sql = ''
        line_info = {}
        sqls = []
        while p.poll() is None:
            line = p.stdout.readline()
            line = line.decode(encoding='utf-8')
            if line.find('HID=NULL') >= 0:
                continue
            if line:
                if line.startswith('ProxySQL LOG QUERY'):
                    # 处理一个行刚好
                    line_info['sql'] = sql
                    sql = ''
                    # print(line_info)
                    sqls.append(line_info)
                    line_info = {}
                    line = line.replace('"', '')
                    parts = line.split()
                    for part in parts:
                        if part in ('ProxySQL', 'LOG', 'QUERY:'):
                            continue
                        elif part.startswith('username'):
                            username = part.split('=')[1]
                            # print(username)
                        elif part.startswith('schemaname'):
                            schemaname = part.split('=')[1]
                            # print(schemaname)
                        elif part.startswith('HID'):
                            HID = part.split('=')[1]
                            # print(HID)
                        elif part.startswith('server'):
                            server = part.split('=')[1]
                            # print(server)
                        elif part.startswith('starttime'):
                            starttime = part.split('=')[1] + ' ' + parts[parts.index(part) + 1].split('.')[0]
                            # print(starttime)
                        elif part.startswith('endtime'):
                            endtime = part.split('=')[1] + ' ' + parts[parts.index(part) + 1].split('.')[0]
                            # print(endtime)
                        elif part.startswith('duration'):
                            duration = part.split('=')[1][0:-2]
                            # print(duration)
                        elif part.startswith('digest'):
                            digest = part.split('=')[1]
                            # print(digest)
                    line_info = {
                        'username': username,
                        'schemaname': schemaname,
                        'HID': HID,
                        'server': server,
                        'starttime': starttime,
                        'endtime': endtime,
                        'duration': duration,
                        'digest': digest
                    }
                else:
                    sql = sql + line

        for log in sqls:
            if log['sql'] == '':
                continue
            elif log['schemaname'] == 'information_schema':
                continue
            elif log['sql'].startswith('/* mysql-connector-java'):
                continue
            elif log['sql'].upper().startswith('SET'):
                continue
            elif log['sql'].upper().startswith('DESC'):
                continue
            elif log['sql'].startswith('/* ApplicationName=DataGrip'):
                continue
            elif log['sql'] in ('select @@character_set_database\n','select @@collation_database\n','\n'):
                continue
            elif log['sql'].upper().find('INFORMATION_SCHEMA') >= 0:
                continue
            if log['sql'].startswith('0.0.83'):
                continue
            elif log['sql'].upper().startswith('SHOW'):
                continue
            elif log['sql'] in (
            'SELECT @@read_only\n', 'SELECT @@version\n', 'select database()','select 1\n','select 1 from dual\n', 'SELECT @@global.max_allowed_packet\n','SELECT current_user()\n'):
                continue
            else:
                if max_time is not None and  datetime.strptime(log['starttime'],'%Y-%m-%d %H:%M:%S') < max_time:
                    continue
                elif log['duration'] == '' or log['HID'] in ('','NULL'):
                    continue
                insert_sql = 'insert into yandi.proxysql_logs(username,schemaname,server,starttime,endtime,duration,digest,`sql`) values(%s,%s,%s,%s,%s,%s,%s,%s)'

                query(insert_sql,
                      log['username'],
                      log['schemaname'],
                      log['server'],
                      log['starttime'].split('.')[0],
                      log['endtime'].split('.')[0],
                      log['duration'],
                      log['digest'],
                      log['sql'][0:4000],
                      commit=True,
                      escape=True)
