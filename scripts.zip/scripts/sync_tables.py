import pymysql

config_db_setting = {
    'host':'172.16.100.36',
    'user':'yunwei',
    'password':'7PMbpSGtFi',
    'port':35972
}

#先获取生产库vip
vips = []
con = pymysql.connect(**config_db_setting)
try:
    with con.cursor() as cursor:
        cursor.execute('select DISTINCT(vip) as vip from yandi.inventory t where t.category="product" and t.deleted=0 and type="mysql"')
        vips = [x[0] for x in cursor.fetchall() if x[0] not in ('172.16.100.201','172.16.100.202','172.16.100.36')]
finally:
    con.close()

#获取生产库所有的表和库的名称
pro_db_tables = {}

for vip in vips:
    get_db_table_sql = f"""
    SELECT
        CONCAT(TABLE_SCHEMA,'|','{vip}'),
        table_name
    FROM
        information_schema.`TABLES` t
    WHERE
        t.TABLE_TYPE = 'BASE TABLE'
    AND t.TABLE_SCHEMA NOT IN (
        'information_schema',
        'performance_schema',
        'mysql',
        'sys',
        'infra'
    )
    """

    port = 54000 if vip == '172.17.200.254' else 35972
    con = pymysql.connect(host=vip, user='yunwei', password='7PMbpSGtFi', port= port , charset='utf8')
    try:
        with con.cursor() as cursor:
            cursor.execute(get_db_table_sql)
            for dbname, table_name in cursor.fetchall():

                if dbname not in pro_db_tables.keys():
                    pro_db_tables[dbname] = [table_name]
                else:
                    pro_db_tables[dbname].append(table_name)
    finally:
        con.close()


#获取发布系统里面配置的库和表
publish_db_tables = {}
publish_db_setting = {
    'host': '172.16.14.253',
    'user': 'yunwei',
    'password': '7PMbpSGtFi',
    'port': 35972,
    'cursorclass': pymysql.cursors.DictCursor,
    'charset':'utf8'
}

con = pymysql.connect(**publish_db_setting)
try:
    with con.cursor() as cursor:
        cursor.execute(
            """
            SELECT
                t1.Id,
                t1.DatasourceName,
                t2.Tablename
            FROM
                publish.t_datasource_info t1
            LEFT JOIN publish.t_datasource_table_info t2 ON t1.id = t2.DatasourceId
            """
        )

    for item in cursor.fetchall():
        key = item['DatasourceName'].split('|')[1] + '|' + item['DatasourceName'].split('|')[2]
        table_name = item['Tablename']
        if key not in publish_db_tables.keys():
            publish_db_tables[key]= {'id':item['Id'],'tables':[table_name]}
        else:
            publish_db_tables[key]['tables'].append(table_name)

    #先处理数据库和表
    for dbname,tables in pro_db_tables.items():
        if dbname not in publish_db_tables.keys():
            #插入数据库
            vip = dbname.split('|')[1]
            if vip == '172.16.14.253':
                dbname_for_insert = 'IDC|'+dbname+'|预发布'
            elif vip == '172.17.200.254':
                dbname_for_insert = 'IDC|' + dbname + '|tidb'
            elif vip == '172.17.100.100':
                dbname_for_insert = 'IDC|' + dbname + '|中新'
            else:
                dbname_for_insert = 'IDC|'+dbname+'|生产'

            with con.cursor() as cursor:
                cursor.execute(f"insert into publish.t_datasource_info(DatasourceName) values('{dbname_for_insert}')")
                cursor.execute("SELECT LAST_INSERT_ID() as id ")
                id = cursor.fetchone()['id']
                cursor.execute("commit")

                #插入表
                cursor.executemany(f"""insert into publish.t_datasource_table_info(DatasourceId,Tablename) values({id},%s)""",tables)
                con.commit()
        else:
            #开始比对表了
            with con.cursor() as cursor:
                for table in tables:
                    if table not in publish_db_tables[dbname]['tables']:
                    #插入数据库
                        cursor.execute(f"""insert into publish.t_datasource_table_info(DatasourceId,Tablename) values({publish_db_tables[dbname]['id']},'{table}')""")
                con.commit()
finally:
    con.close()

