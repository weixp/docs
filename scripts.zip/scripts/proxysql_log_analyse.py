# -*- coding: utf-8 -*-
import os
import traceback
import shlex
import subprocess
import time
from datetime import datetime
from utilities import get_host,get_config,query

#获取配置信息
host = get_host()
config = get_config(host=host)
get_max_time_sql = f"select max(starttime) max_time from yandi.proxysql_logs where server = '{host}:35972'"

max_time = query(get_max_time_sql)

if len(max_time) == 0:
    max_time = None
else:
    max_time = max_time[0]['max_time']
    max_timestamp = time.mktime(max_time.timetuple())

os.chdir('/var/lib/proxysql')

processed_lines = []

for file in os.listdir('/var/lib/proxysql'):

    if file.startswith('queries.log.') :
        m_time = os.stat(file).st_mtime
        if max_time is not None and m_time <max_timestamp:
            continue
        cmd = shlex.split(f'/usr/share/proxysql/proxysql-1.4.4/tools/eventslog_reader_sample {file}')
        p = subprocess.Popen(cmd, shell=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        line_info = []
        while p.poll() is None:
            line = p.stdout.readline()
            line = line.decode(encoding='utf-8')

            if line.find('ProxySQL LOG QUERY')>=0  :
                if len(line_info) != 0:
                    processed_lines.append(line_info)
                line_info = [line,'']
            else:
                line_info[1] = line_info[1] + line

        #首先把服务器等信息和sql的信息放在一个数组里面，好等到后续一起处理
        #开始处理
        for line,sql in processed_lines:
            #先处理line,如果line当中包括
            if line.find('schemaname=information_schema') > 0 or sql.upper().find('INFORMATION_SCHEMA') >0:
                continue
            elif line.find('HID=NULL') > 0:
                continue
            elif sql in ('SELECT @@read_only\n',
                         'SELECT @@version\n',
                         'select database()',
                         'select 1\n',
                         'select schema()\n'
                         'select 1 from dual\n',
                         'SELECT @@global.max_allowed_packet\n',
                         'SELECT current_user()\n',
                         'select @@character_set_database\n',
                         'select @@collation_database\n',
                         'SELECT @@lower_case_table_names\n',
                         'SELECT @@have_profiling\n'
                          '\n'):
                continue
            elif sql.upper().startswith('SHOW'):
                continue
            elif sql.upper().startswith('DESC'):
                continue
            elif sql.startswith('/* ApplicationName=DataGrip'):
                continue
            elif sql.startswith('/* mysql-connector-java'):
                continue
            elif sql.upper().startswith('SET'):
                continue
            else:
                #处理过滤完的,先提取line的重要组成部分
                line = line.replace('"','')
                parts = line.split()
                for part in parts:
                    if part in ('ProxySQL', 'LOG', 'QUERY:'):
                        continue
                    elif part.startswith('username'):
                        username = part.split('=')[1]
                        #print(username)
                    elif part.startswith('schemaname'):
                        schemaname = part.split('=')[1]
                        #print(schemaname)
                    elif part.startswith('HID'):
                        HID = part.split('=')[1]
                        #print(HID)
                    elif part.startswith('server'):
                        server = part.split('=')[1]
                        #print(server)
                    elif part.startswith('starttime'):
                        starttime = part.split('=')[1] + ' ' + parts[parts.index(part) + 1].split('.')[0]
                        #print(starttime)
                    elif part.startswith('endtime'):
                        endtime = part.split('=')[1] + ' ' + parts[parts.index(part) + 1].split('.')[0]
                        #print(endtime)
                    elif part.startswith('duration'):
                        duration = part.split('=')[1][0:-2]
                        #print(duration)
                    elif part.startswith('digest'):
                        digest = part.split('=')[1]
                        #print(digest)
                    insert_sql = 'insert into yandi.proxysql_logs(username,schemaname,server,starttime,endtime,duration,digest,`sql`) values(%s,%s,%s,%s,%s,%s,%s,%s)'

                query(insert_sql,
                      username,
                      schemaname,
                      server,
                      starttime,
                      endtime,
                      duration,
                      digest,
                      sql[0:4000],
                      commit=True,
                      escape=True)