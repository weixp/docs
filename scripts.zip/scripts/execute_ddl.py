import pymysql
import argparse
import sys
import logging
import json

logging.basicConfig(level=logging.DEBUG,
                    filename='cron.log')

def get_projectinfo(projectid):
    """项目发布中的工单"""
    conn = pymysql.connect(host='172.16.14.253', user='cuitenghui', password='V7QuEGhsLLFWV7AW', port=35972,
                           charset='utf8', cursorclass=pymysql.cursors.DictCursor)
    cursor = conn.cursor()
    try:
        sql = """
            SELECT
                t1.ExecuteSql
            FROM
                publish.t_publish_info t1,
                publish.t_audit_flow t2
            WHERE
                t1.Id = t2.PublishInfoId
            AND t2.Id = {};
            """.format(projectid)
        cursor.execute(sql)
        results = cursor.fetchall()
        for gd in results:
            for db_info, submit_sql in json.loads(gd['ExecuteSql']).items():
                if submit_sql['ddl'] == '':
                    raise Exception('项目发布中的%s号工单不存在DDL语句,该脚本只执行含有DDL的工单,请核实!' % projectid)
                elif submit_sql['ddl'] != '':
                    db_name = db_info.split('|')[1]
                    vip = db_info.split('|')[2]
                    ddl_sql = submit_sql['ddl']
                    execute_sql(projectid, db_name, vip, ddl_sql)
    except Exception as e:
        logging.error(e)
    finally:
        conn.close()

def get_info(gd_id):
    """get execute info(host, database, ddl)"""
    conn = pymysql.connect(host='172.16.14.253', user='cuitenghui', password='V7QuEGhsLLFWV7AW', port=35972, charset='utf8', cursorclass=pymysql.cursors.DictCursor)
    cursor = conn.cursor()
    try:
        sql = "select Discribe from publish.t_process_info where id = {}".format(gd_id)
        cursor.execute(sql)
        results = cursor.fetchall()
        for gd in results:
            for db_info, submit_sql in json.loads(gd['Discribe'])['executeSql'].items():
                if submit_sql['ddl'] == '':
                    raise Exception('%s号工单不存在DDL语句,该脚本只执行含有DDL的工单,请核实!' % gd_id)
                elif submit_sql['ddl'] != '':
                    db_name = db_info.split('|')[1]
                    vip = db_info.split('|')[2]
                    ddl_sql = submit_sql['ddl']
                    execute_sql(gd_id, db_name, vip, ddl_sql)
    except Exception as e:
        logging.error(e)
    finally:
        conn.close()

def execute_sql(gd_id, db_name, vip, ddl_sql):
    """connect to MySQL Server"""
    conn = pymysql.connect(host='192.168.87.130', user='root', password='cuitenghui', port=3306, charset='utf8')
    cursor = conn.cursor()
    try:
        sql = "use `test`;"
        cursor.execute(sql)
        # cursor.execute(ddl_sql)
        print(sql)
        print(ddl_sql)
        logging.info('%s号工单的DDL语句执行成功!' % gd_id)
    except Exception as e:
        logging.error(e)
    finally:
        conn.commit()
        conn.close()

def get_gd(args):
    """parse args for sql"""
    parser = argparse.ArgumentParser(description='Execute cron_sql', add_help=False)
    parser.add_argument('-i', '--id', dest='id', type=str, help='需执行的DDL语句在发布系统对应的工单号', default='')
    parser.add_argument('-p', '--ProjectId', dest='ProjectId', type=str, help='项目发布中需执行的DDL语句对应编号', default='')
    parser.add_argument('--help', dest='help', action='store_true', help='help information', default=False)
    need_print_help = False if args else True
    args = parser.parse_args()
    if args.help or need_print_help:
        parser.print_help()
    else:
        # 需要执行多个工单号，命令行用,分割多个工单号
        gd_id_list = args.id.split(',')
        for gd_id in gd_id_list:
            get_info(gd_id)
        # 项目发布的单子
        projectid_list = args.ProjectId.split(',')
        for projectid in projectid_list:
            get_projectinfo(projectid)

if __name__ == '__main__':
    get_gd(sys.argv[1:])