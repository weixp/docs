import subprocess
import shlex
import sys
import pymysql

config_db_host = '172.16.100.36'
config_db_user = 'weixinping'
config_db_pwd = '$X2EGrRt'
config_db_port = 35972

con = pymysql.connect('172.16.100.23','weixinping','$X2EGrRt',port=35972)
cursor=con.cursor()
table = 't_taobao_crawler_info'

for i in range(1,641):
    #num=cursor.execute(f'insert into ecommerce.{table}( BaseInfoId,UserId,BankId,BankName,CardNo,CardType,CardOwnerName,IsExpress,Status,CreateDate,LastUpdateDate) select  BaseInfoId,UserId,BankId,BankName,CardNo,CardType,CardOwnerName,IsExpress,Status,CreateDate,LastUpdateDate from ecommerce{i}.{table}')
    num=cursor.execute(f'insert into ecommerce.{table}( ) select  * from ecommerce{i}.{table}')
    #num = cursor.execute(f'insert into ecommerce.{table}( BaseInfoId,UserId,BankId,BankName,CardNo,CardOwnerName,Status,CardIsOwner,CreateDate,LastUpdateDate) select  BaseInfoId,UserId,BankId,BankName,CardNo,CardOwnerName,Status,CardIsOwner,CreateDate,LastUpdateDate from ecommerce{i}.{table}')
    #num = cursor.execute(f'insert into ecommerce.{table}( BaseInfoId,UserId,Category,City,Organization,AccountName,AccountCode,RemindTime,Status,CreateDate,LastUpdateDate) select  BaseInfoId,UserId,Category,City,Organization,AccountName,AccountCode,RemindTime,Status,CreateDate,LastUpdateDate from ecommerce{i}.{table}')
    print(num)
    con.commit()
con.close()