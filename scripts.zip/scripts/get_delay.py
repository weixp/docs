#!/usr/local/bin/python3
import datetime
import pymysql
from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.event import QueryEvent, RotateEvent, FormatDescriptionEvent ,GtidEvent,XidEvent
from pymysqlreplication.row_event import (
    WriteRowsEvent,
    UpdateRowsEvent,
    DeleteRowsEvent,
)
from pymysqlreplication.event import  RotateEvent, FormatDescriptionEvent
import configparser
import os

#获取配置信息
"""

config_file = '/app/scripts/config.cnf'
config = configparser.ConfigParser()
config.read(config_file if os.path.exists(config_file) else 'config.cnf')
local_ip = config['machine']['host']
master_ip = config['machine']['master']
host=config['config_db']['host']
user=config['config_db']['user']
password=config['config_db']['password']
port=config['config_db']['port']
"""
slave_ip = '172.16.100.29'
master_ip = '172.16.100.28'
#从主库获取下一个event内容
con = pymysql.connect(slave_ip, 'weixinping', '$X2EGrRt', port=35972, cursorclass=pymysql.cursors.DictCursor)
try:
    # 先获取从库的位置
    cursor = con.cursor()
    cursor.execute('show slave status')
    result = cursor.fetchone()
    start_file = result['Relay_Master_Log_File']
    start_pos = result['Exec_Master_Log_Pos']

    conn_setting = {'host':master_ip , 'port': 35972, 'user': 'weixinping', 'passwd': '$X2EGrRt', 'charset': 'utf8mb4'}

    stream = BinLogStreamReader(connection_settings=conn_setting, server_id=14, log_file=start_file,
                                log_pos=start_pos, resume_stream=True, blocking=True)
    try:
        for binlog_event in stream:

            if isinstance(binlog_event, WriteRowsEvent) or isinstance(binlog_event, UpdateRowsEvent) or isinstance(binlog_event, DeleteRowsEvent):
                event_time = datetime.datetime.fromtimestamp(binlog_event.timestamp)
                sql_type = ''
                if isinstance(binlog_event, WriteRowsEvent):
                    sql_type = 'INSERT'
                elif isinstance(binlog_event, UpdateRowsEvent):
                    sql_type = 'UPDATE'
                elif isinstance(binlog_event, DeleteRowsEvent):
                    sql_type = 'DELETE'

                table = binlog_event.schema + '.' + binlog_event.table
                affted_rows = len(binlog_event.rows)
                message = '从{0}开始,表{1}被{2}了{3}条'.format(event_time,table,sql_type,affted_rows)
                print(message)

                break

            #下面一块基本是ddl
            elif isinstance(binlog_event, QueryEvent) and binlog_event.query != 'BEGIN':
                event_time = datetime.datetime.fromtimestamp(binlog_event.timestamp)
                message = '{0}ddl操作:{1}'.format(event_time,binlog_event.query)
                print(message)

                break

    finally:
        stream.close()

finally:
    con.close()

    #14938720