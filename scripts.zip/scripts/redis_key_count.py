from redis import Redis
con = Redis(host='172.17.100.206',password="Dashu0701")

info = con.info()
print(info)
keys = 0
for key,value in info.items():
    if key.startswith('db'):
        print(key)
        print(value)
        keys = keys+value['keys']

print(keys)