import pymysql

"""CREATE USER 'admin'@'%' IDENTIFIED WITH 'mysql_native_password' AS '*4ACFE3202A5FF5CF467898FC58AAB1D615029441'"""


ip = '172.17.100.24'
port = 35972
user = 'admin'
password = 'Q@XXA8Yj'
con = pymysql.connect(ip,user,password,port=port)
cursor = con.cursor()
cursor.execute("select user,host,authentication_string from mysql.`user` t where t.`User` not in ('mysql.session','mysql.sys')")
results = cursor.fetchall()
for (name,host,pwd) in results:
    print(f"""CREATE USER '{user}'@'{host}' IDENTIFIED WITH 'mysql_native_password' AS '{pwd}';"""
)
    #获取权限
    cursor.execute(f"show grants for '{name}'@'{host}'")
    for result in cursor.fetchall():
        if result[0].startswith('GRANT USAGE'):
            continue
        print(result[0]+';')
    print('------------------')
con.close()