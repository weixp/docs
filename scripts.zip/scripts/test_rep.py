from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.row_event import DeleteRowsEvent,WriteRowsEvent,UpdateRowsEvent
from pymysqlreplication.event import QueryEvent
import time
import timeout_decorator
import pymysql

class event():

    def __init__(self,action,table_name,rows):
        self.action = action
        self.table_name = table_name
        self.rows = rows
        self.times = 0


MYSQL_SETTINGS = {
    'host' : '192.168.116.138',
    'user' : 'weixinping',
    'password' : '$X2EGrRt',
    'port':5721
}

slave_settings = {
    'host' : '172.17.100.29',
    'user' : 'weixinping',
    'password' : '$X2EGrRt',
    'port':5721,
    'cursorclass':pymysql.cursors.DictCursor
}

action_dic = {}

'Relay_Master_Log_File'
'Exec_Master_Log_Pos'



def main():
    stream = BinLogStreamReader(
        connection_settings=MYSQL_SETTINGS,
        server_id=4,
        blocking=True,
        log_file='bin-log.000001'
    )
    try:
        for binlogevent in stream:
            if isinstance(binlogevent,QueryEvent):
                print(binlogevent.query)
    finally:
        stream.close()

if __name__ == "__main__":
    main()

#也就是说按照这个去拿的话，会获取上一个gtid后面的值


#10:27:48