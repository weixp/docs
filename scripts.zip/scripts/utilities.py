"""一些公用的函数，比如数据库sql执行和邮件发送还有工单点击"""
import pymysql
from email.mime.text import MIMEText
from email.utils import formataddr
import smtplib
import netifaces

con_dic = {
    'host':'172.16.100.36',
    'user':'yunwei',
    'password':'7PMbpSGtFi',
    'database':'yandi',
    'port':35972,
    'cursorclass':pymysql.cursors.DictCursor
}

CONFIG = None

#加载公共账号密码等配置
sql = f"select * from yandi.config_all "
con = pymysql.connect(**con_dic)
try:
    cursor = con.cursor()
    cursor.execute(sql)
    CONFIG = cursor.fetchone()
finally:
    con.close()



#获取单个服务器自己的配置
def get_config(host):

    if host is None:
        raise Exception('host can not be None')

    sql = f"select * from yandi.config_all a,yandi.config_single b where b.`host` = '{host}'  and b.deleted is false"

    return query(sql=sql)[0]


#获取机器ip
def get_host(interface=None):

    if interface is None:
        interface = 'bond0' if 'bond0' in netifaces.interfaces() else 'eth0'

    return netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['addr']


#def get_mysql_masters():
#    sql = 'select * from yandi.'

#执行sql语句
def query(sql,*args,host=None,port=35972,database=None,commit=False,escape=False):
    if host is None:
        host=con_dic['host']
    con = pymysql.connect(host=host,
                          user=CONFIG['operator'],
                          password=CONFIG['password'],
                          charset='utf8mb4',
                          port=port,
                          database=database,
                          cursorclass=pymysql.cursors.DictCursor)
    try:
        with con.cursor() as cursor:
            if escape :
                cursor.execute(sql,args)
            else:
                cursor.execute(sql)
            return cursor.fetchall()
    finally:
        if commit :
            con.commit()

        con.close()

def send_email(content,subject,email=''):

    my_sender = 'idc@treefintech.com'  # 发件人邮箱账号
    my_pass = 'W0@Mail.ds'  # 发件人邮箱密码(当时申请smtp给的口令)
    my_user = [email,
               'weixinping@treefintech.com',
               'cuitenghui@treefintech.com',
               'guofushan@treefintech.com',
               'heshan@treefintech.com',
               'haungturui@treefintech.com']  # 收件人邮箱账号，我这边发送给自己
    if email == '':
        my_user.remove('')

    msg = MIMEText(content, 'plain', 'utf-8')
    msg['From'] = formataddr(["大树金科运维组", my_sender])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
    msg['To'] = formataddr(["大树金科员工", ','.join(my_user)])  # 括号里的对应收件人邮箱昵称、收件人邮箱账号
    msg['Subject'] = subject  # 邮件的主题，也可以说是标题
    server = smtplib.SMTP_SSL("smtp.exmail.qq.com", 465)  # 发件人邮箱中的SMTP服务器，端口是465
    server.login(my_sender, my_pass)  # 括号中对应的是发件人邮箱账号、邮箱密码
    server.sendmail(my_sender, my_user, msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
    server.quit()
