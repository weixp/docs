"""
#-*- coding: utf-8 -*-
from scapy.all import *


def packet_callbacke(pkt):
    #pkt.show()
    if hasattr(pkt['TCP'],'load') :
        #print()
        print(pkt['TCP'].load[4] == 3)
        print(pkt['TCP'].load[5:])


pkts = sniff(iface='utun2' ,filter="tcp dst port 35972", prn=packet_callbacke,count=0)

"""

#-*- coding: utf-8 -*-
from scapy.all import *


def packet_callbacke(pkt):
    if   pkt.haslayer('TCP') and pkt['IP'].dst=='172.17.100.26'  and hasattr(pkt['TCP'],'load') and len(pkt['TCP'].load) > 5 and  pkt['TCP'].load[4]==3:
        print(pkt['TCP'].load[5:])

pkts = sniff(iface='bond0' , prn=packet_callbacke,count=0)
