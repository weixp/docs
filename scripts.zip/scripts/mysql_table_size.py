import pymysql
import paramiko
import stat

conn = pymysql.connect(host='172.16.100.36', user='cuitenghui', password='V7QuEGhsLLFWV7AW', port=35972, charset='utf8')
cursor = conn.cursor()

vips = ['172.16.100.203', '172.16.100.204', '172.16.100.205', '172.17.100.203', '172.17.100.204', '172.16.14.253']
for vip in vips:
    if vip == '172.16.14.253':
        passwd = 'Dashu&jinrong50'
    else:
        passwd = '1!deshine'
    # ssh connection
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=vip, port=22, username='root', password=passwd)
    # sftp connection
    tran = paramiko.Transport((vip, 22))
    tran.connect(username='root', password=passwd)
    sftp = paramiko.SFTPClient.from_transport(tran)

    """
    stdin, stdout, stderr = ssh.exec_command("du -sh /app/mysql/data")
    ins_size = str(stdout.read().decode('utf-8')).split('\t')[0]
    print('该实例的大小为 %s\n' % ins_size)
    """

    db_dir = r'/app/mysql/data'
    db_files = sftp.listdir_attr(db_dir)
    for db in db_files:
        if stat.S_ISDIR(db.st_mode):
            table_dir = (r'/app/mysql/data/%s' % db.filename)
            """
            stdin, stdout, stderr = ssh.exec_command("du -sh %s" % filename)
            db_size = str(stdout.read().decode('utf-8')).split('\t')[0]
            print('%s数据库文件的大小为 %s\n各表数据文件大小如下:' % (db.filename, db_size))
            """
            # listdir_attr 会把文件以linux中ll命令的形式展现
            table_files = sftp.listdir_attr(table_dir)
            for table in table_files:
                filetype = table.filename.split('.')
                if filetype[1] == 'ibd':
                    stdin, stdout, stderr = ssh.exec_command("du -sh %s/%s" % (table_dir, table.filename))
                    table_size = stdout.read().decode('utf-8').split('\t')[0]
                    # saved table_size as KB
                    if table_size.endswith('K'):
                        table_size = table_size.replace('K', '')
                    elif table_size.endswith('M'):
                        table_size = float(table_size.replace('M', ''))*1024
                    elif table_size.endswith('G'):
                        table_size = float(table_size.replace('G', ''))*1024*1024
                    elif table_size.endswith('T'):
                        table_size = float(table_size.replace('T', ''))*1024*1024*1024
                    insert_sql = """
                    INSERT INTO fuxi.tables_size (
                        db_name,
                        table_name,
                        vip,
                        table_size
                    )
                    VALUES
                        ('{0}', '{1}', '{2}', '{3}');
                    """.format(db.filename, filetype[0], vip, table_size)
                    # print(insert_sql)
                    cursor.execute(insert_sql)
                    conn.commit()
                    # print('%s %sK' % (table.filename, int(table.st_size/1024)))
    ssh.close()
    tran.close()
cursor.close()