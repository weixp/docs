import datetime
from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.row_event import DeleteRowsEvent,WriteRowsEvent,UpdateRowsEvent



MYSQL_SETTINGS = {
    'host' : '10.0.10.60',
    'user' : 'weixinping',
    'password' : '$X2EGrRt',
    'port':35972
}

import time
timeArray = time.strptime('2019-12-18 14:58:00', "%Y-%m-%d %H:%M:%S")
start_time = int(time.mktime(timeArray))
stop_time = int(time.mktime(time.strptime('2019-12-18 15:10:00', "%Y-%m-%d %H:%M:%S")))

action_dic = {}
stream = BinLogStreamReader(
    connection_settings=MYSQL_SETTINGS,
    server_id=3,
    blocking=False,
    #only_schemas=['zxxd_credit_report'],
    #only_tables=['rhzx_outside_value_compare'],
    only_events=[DeleteRowsEvent, WriteRowsEvent, UpdateRowsEvent],
    log_file='bin-log.000045',
    log_pos=4
)
try:
    for binlogevent in stream:

        #table_name = f'{binlogevent.schema}.{binlogevent.table}'
        #rows = len(binlogevent.rows)
        #print(binlogevent.schema)
        if binlogevent.timestamp < start_time :
            continue

        if binlogevent.timestamp > stop_time :
            break

        #print('update', binlogevent.table, time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(binlogevent.timestamp)))
        table_name = binlogevent.table
        rows = len(binlogevent.rows)

        if datetime.datetime.fromtimestamp(binlogevent.timestamp) not in action_dic.keys():
            action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)] = {}


        if isinstance(binlogevent, UpdateRowsEvent):
            if f'{table_name}update' not in action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)].keys():
                action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)][f'{table_name}update']=[rows]
            else:
                action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)][f'{table_name}update'].append(rows)
        elif isinstance(binlogevent, DeleteRowsEvent):
            if f'{table_name}delete' not in action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)].keys():
                action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)][f'{table_name}delete']=[rows]
            else:
                action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)][f'{table_name}delete'].append(rows)
        elif isinstance(binlogevent, WriteRowsEvent):
            if f'{table_name}insert' not in action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)].keys():
                action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)][f'{table_name}insert']=[rows]
            else:
                action_dic[datetime.datetime.fromtimestamp(binlogevent.timestamp)][f'{table_name}insert'].append(rows)
finally:
    stream.close()
#print(action_dic)

for item in action_dic.items():
    print(item[0].strftime('%Y-%m-%d %H:%M:%S'))
    for table in item[1].items():
        #print(table)
        print(table[0],len(table[1]),sum(table[1]),table[1])