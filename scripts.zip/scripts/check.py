from datetime import datetime,date
from email.mime.text import MIMEText
from email.utils import formataddr
import smtplib
import logging
import pymysql
import traceback

config_db_host = '172.16.100.36'
config_db_user = 'yunwei'
config_db_pwd = '7PMbpSGtFi'
config_db_port = 35972

today = date.today()

ips = []
con = pymysql.connect(config_db_host,
                      config_db_user,
                      config_db_pwd,
                      port=config_db_port,
                      cursorclass=pymysql.cursors.DictCursor)
try:
    with con.cursor() as cursor:
        cursor.execute(f'select * from yandi.xtrabackup where deleted is false')
        results = cursor.fetchall()

    backup_content = """
    <table border="1">
    <tr><td>实例ip</td><td>是否成功</td><td>备份时间</td></tr>
    """

    for instance in results:
        if datetime.date(instance['date_updated']) == today:
            backup_content += f"""<tr><td>{instance['ip']}</td><td>成功</td><td>{instance['date_updated']}</td></tr>"""
        else:
            backup_content += f"""<tr><td>{instance['ip']}</td><td><p style="color:red;">失败</p></td><td>{instance['date_updated']}</td></tr>"""

    backup_content = backup_content + "</table>"

    #查看归档情况
    with con.cursor() as cursor:
        cursor.execute(f'select * from yandi.pt_archiver t where t.deleted is false  order by t.db_name desc')
        results = cursor.fetchall()

    archive_content = """
    <table border="1">
    <tr><td>数据库名</td><td>表名</td><td>归档行数</td></tr>
    """
    for table in results:
        if datetime.date(table['date_updated']) == today:
            archive_content += f"""<tr><td>{table['db_name']}</td><td>{table['table_name']}</td><td>{table['last_archive_rows']}</td></tr>
            """
        else:
            archive_content += f"""<tr><td>{table['db_name']}</td><td>{table['table_name']}</td><td><p style="color:red;">失败</p></td></tr>
            """

    archive_content = archive_content + "</table>"

    #mysql数据库大小统计查看
    #先拿到生产所有的mysql数据库ip
    with con.cursor() as cursor:
        cursor.execute('select DISTINCT(vip) as vip from yandi.inventory t where t.category="product" and type="mysql" ')
        mysql_vips = cursor.fetchall()

    db_sizes = {}

    for vip in mysql_vips:
        db_size_con = pymysql.connect(vip['vip'],config_db_user,config_db_pwd,port=config_db_port)
        try:
            with db_size_con.cursor() as db_size_cursor:
                if vip['vip'] == '172.16.100.201':
                    db_size_cursor.execute("""
                                            SELECT
                                                'operator',
                                                round(sum(t.DATA_LENGTH + t.INDEX_LENGTH) / 1024 / 1024 / 1024) GB
                                            FROM
                                                information_schema.`TABLES` t
                                            WHERE
                                                TABLE_SCHEMA NOT IN (
                                                    'sys',
                                                    'information_schema',
                                                    'mysql',
                                                    'performance_schema'
                                                )
                                           """)
                elif vip['vip'] == "172.16.100.202":
                    db_size_cursor.execute("""
                                            SELECT
                                                'ecommerce',
                                                round(sum(t.DATA_LENGTH + t.INDEX_LENGTH) / 1024 / 1024 / 1024) GB
                                            FROM
                                                information_schema.`TABLES` t
                                            WHERE
                                                TABLE_SCHEMA NOT IN (
                                                    'sys',
                                                    'information_schema',
                                                    'mysql',
                                                    'performance_schema'
                                                )
                                           """)
                else:
                    db_size_cursor.execute("""SELECT
                                                    t.TABLE_SCHEMA,
                                                    round(
                                                        sum(t.DATA_LENGTH + t.INDEX_LENGTH) / 1024 / 1024 / 1024
                                                    ) GB
                                              FROM
                                                    information_schema.`TABLES` t
                                              WHERE
                                                    TABLE_SCHEMA NOT IN (
                                                        'sys',
                                                        'information_schema',
                                                        'mysql',
                                                        'performance_schema'
                                                    )
                                              GROUP BY
                                                    t.TABLE_SCHEMA 
                                            """)

            for db_size in  db_size_cursor.fetchall():
                if db_size[1] > 10 :
                    db_sizes[db_size[0]]=db_size[1]
        finally:
            db_size_con.close()
    sorted_db_sizes = sorted(db_sizes.items(), key=lambda x:x[1], reverse=True)
    db_size_content = """
    <table border="1">
    <tr><td>db_name</td><td>size</td></tr>
    """

    for db_size in sorted_db_sizes:
        db_size_content += f"""<tr><td>{db_size[0]}</td><td>{db_size[1]}GB</td></tr>"""

    db_size_content = db_size_content + "</table>"

    #大表监控



    content = f"""
    <html>
    <head>
    <h2>数据库每日检查项</h2>
    </head>
    <body>
    <ul>
    <li>mysql备份检查</li>
    {backup_content}
    <li>归档情况</li>
    {archive_content}
    <li>数据库大小(大于10G的库)</li>
    {db_size_content}
    </ul>
    """

    #发送邮件
    my_sender = 'idc@treefintech.com'  # 发件人邮箱账号
    my_pass = 'W0@Mail.ds'  # 发件人邮箱密码(当时申请smtp给的口令)
    my_user = ['dba@treefinance.com.cn']  # 收件人邮箱账号，我这边发送给自己
    #my_user = ['weixinping@treefinance.com.cn']
    msg = MIMEText(content, 'html', 'utf-8')
    msg['From'] = formataddr(["大树金科DBA", my_sender])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
    msg['To'] = formataddr(["大树金科DBA", ','.join(my_user)])  # 括号里的对应收件人邮箱昵称、收件人邮箱账号
    msg['Subject'] = '数据库每日检查项'  # 邮件的主题，也可以说是标题
    server = smtplib.SMTP_SSL("smtp.exmail.qq.com", 465)  # 发件人邮箱中的SMTP服务器，端口是465
    server.login(my_sender, my_pass)  # 括号中对应的是发件人邮箱账号、邮箱密码
    server.sendmail(my_sender, my_user, msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
    server.quit()

except Exception as e:
    traceback.print_exc()
    logging.error(traceback.format_exc())
    raise
finally:
    con.close()