# -*- coding: utf-8 -*-
import json
import subprocess
import shlex
import traceback
import time
import pymysql
from email.mime.text import MIMEText
from email.utils import formataddr
import smtplib
import sqlparse

def send_email(content,email=''):

    my_sender = 'idc@treefintech.com'  # 发件人邮箱账号
    my_pass = 'W0@Mail.ds'  # 发件人邮箱密码(当时申请smtp给的口令)
    my_user = [email,'dba@treefinance.com.cn']  # 收件人邮箱账号，我这边发送给自己

    if email == '':
        my_user.remove('')

    msg = MIMEText(content, 'plain', 'utf-8')
    msg['From'] = formataddr(["大树金科DBA", my_sender])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
    msg['To'] = formataddr(["大树金科员工", ','.join(my_user)])  # 括号里的对应收件人邮箱昵称、收件人邮箱账号
    msg['Subject'] = '数据修改工单执行结果'  # 邮件的主题，也可以说是标题
    server = smtplib.SMTP_SSL("smtp.exmail.qq.com", 465)  # 发件人邮箱中的SMTP服务器，端口是465
    server.login(my_sender, my_pass)  # 括号中对应的是发件人邮箱账号、邮箱密码
    server.sendmail(my_sender, my_user, msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
    server.quit()

def click_gongdan(id):
    from selenium import webdriver
    try:
        chrome_options = webdriver.ChromeOptions()
        chrome_options.binary_location='/usr/bin/google-chrome'
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--disable-dev-shm-usage')
        driver = webdriver.Chrome('/usr/bin/chromedriver',chrome_options=chrome_options)
        driver.get('http://172.16.14.197:1338/processOper')
        driver.find_element_by_id('identifier').send_keys('魏新平')
        driver.find_element_by_id('password').send_keys('wxp@772008')
        driver.find_element_by_xpath('/html/body/div[2]/div/section/div[2]/form/button').click()
        time.sleep(3)
        gongdan_index = 1
        for i in driver.find_elements_by_xpath('//*[@id="table-flow"]/tbody/tr'):
            if i.text.split()[0] == 'No':
                driver.quit()
                #print('当前没有工单可以点击')
                continue
            if int(i.text.split()[0]) == id :
                driver.find_element_by_xpath('//*[@id="table-flow"]/tbody/tr[{0}]/td[7]/a'.format(gongdan_index)).click()
                time.sleep(3)
                driver.find_element_by_xpath('//*[@id="id_buttons"]/button[4]').click()
                time.sleep(2)
                driver.find_element_by_xpath('/html/body/div[4]/div/div/div[3]/button[2]').click()
                #print('%s号工单已经通过' % (i.text.split()[0]))
                time.sleep(3)
                driver.quit()
                break
            gongdan_index = gongdan_index + 1
    except :
        traceback.print_exc()
    finally:
        subprocess.run('pkill chrome',shell=True)

get_gd_sql = '''
SELECT
    t.Id id,
    t.Discribe db,
    t1.email email,
    t1.username username,
    t.type type
FROM
    publish.t_process_info t,
    publish.`USER` t1
WHERE
    t.Applicant = t1.id
AND t.type = 2
AND t1.isactive = 1
and t.status = 5
and t.id not in (select executed_id from publish.executed_gd)
'''

con = None
gds = []
try:
    con = pymysql.connect('172.16.14.253','yunwei','7PMbpSGtFi',port=35972,cursorclass=pymysql.cursors.DictCursor)
    cursor = con.cursor()
    cursor.execute(get_gd_sql)
    gds = cursor.fetchall()
finally:
    if con is not None:
        con.close()


for gd in gds:

    id = gd['id']
    email = gd['email']

    try:
        # 第一步循环排除mycat库和tidb库还有ddl
        for db, original_sqls in json.loads(gd['db'])['executeSql'].items():

            if not db.upper().startswith('IDC') :
                raise Exception(F'工单{id}是非IDC数据库，需要DBA手动执行')

            if db.find('172.17.200.254') >= 0:
                raise Exception(F'工单{id}是tidb数据库，不支持自动更新，如有更新需求，请联系大数据部门')

        #开始执行语句
        for db, original_sqls in json.loads(gd['db'])['executeSql'].items():

            vip = db.split('|')[2]
            dbname = db.split('|')[1]
            raw_ddl_sql = original_sqls['ddl']

            for sql in sqlparse.split(raw_ddl_sql.upper()):
                parts = sql.strip().split()
                if parts[0] == 'CREATE' and parts[1] == 'TABLE':
                    raise Exception(F'工单{id}包含创建表语句，需要DBA手动执行')

            with open(f'/app/scripts/dml_scripts/{id}_execute.sql', 'w',encoding = 'utf-8') as execute_file:
                execute_file.write(f'use `{dbname}` ;\n')
                execute_file.write(raw_ddl_sql)

            # 执行sql文件，整个脚本执行时间不能超过180秒
            args = shlex.split(f"""/app/mysql/dist/bin/mysql
                                    --defaults-file=/app/scripts/dml_scripts/my.cnf 
                                    -h{vip}
                                    -e 'source /app/scripts/dml_scripts/{id}_execute.sql' """)

            subprocess.run(args,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            encoding='utf-8',
                            check=True,
                            timeout=180)

            raw_dml_sql = original_sqls['dml']

            # 创建sql文件，用于mysql客户端执行
            with open(f'/app/scripts/dml_scripts/{id}_execute.sql', 'w',encoding = 'utf-8') as execute_file:
                execute_file.write(f'use `{dbname}` ;\nset autocommit=off;\n')
                execute_file.write(raw_dml_sql)
                execute_file.write(';\ncommit;')

            # 执行sql文件，整个脚本执行时间不能超过180秒
            args = shlex.split(f"""/app/mysql/dist/bin/mysql
                                    --defaults-file=/app/scripts/dml_scripts/my.cnf 
                                    -h{vip}
                                    -e 'source /app/scripts/dml_scripts/{id}_execute.sql' """)

            subprocess.run(args,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            encoding='utf-8',
                            check=True,
                            timeout=180)

            click_gongdan(id)

            send_email(f'数据修改工单{id}执行成功',email=email)

    except subprocess.CalledProcessError as e:
        send_email(f'数据修改工单{id}执行出问题:'+e.stderr,email=email)

    except Exception as e:
        send_email(f'数据修改工单{id}执行出问题:' + str(e), email=email)

    finally:
        #插入已经执行的工单表当中，防止重复执行
        try:
            con = pymysql.connect('172.16.14.253',
                                  'yunwei',
                                  '7PMbpSGtFi',
                                  port=35972,
                                  cursorclass=pymysql.cursors.DictCursor)
            cursor = con.cursor()
            cursor.execute(f'''insert into publish.executed_gd(executed_id) values('{id}')''')
        finally:
            if con is not None:
                con.commit()
                con.close()
