#!/usr/local/bin/python3
from datetime import datetime,timedelta
import shutil
import logging
import subprocess
import os
import shlex
import netifaces
import pymysql
import traceback

#开启备份日志
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s  %(levelname)s  %(message)s',
                    datefmt='[%d/%b/%Y %H:%M:%S]',
                    filename='/tmp/mysql_backup.log',
                    filemode='w')

config_db_host = '172.16.100.36'
config_db_user = 'yunwei'
config_db_pwd = '7PMbpSGtFi'
config_db_port = 35972
backup_user = 'admin'
backup_pwd = 'Q@XXA8Yj'

#获取本地ip
interface = 'bond0' if 'bond0' in netifaces.interfaces() else 'eth0'
host = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['addr']


#获取配置
con = None
try:
    con = pymysql.connect(config_db_host,
                          config_db_user,
                          config_db_pwd,
                          port=config_db_port,
                          cursorclass=pymysql.cursors.DictCursor)
    cursor = con.cursor()
    cursor.execute(f'select * from yandi.xtrabackup where ip = "{host}"')
    configs = cursor.fetchone()
except Exception as e:
    traceback.print_exc()
    logging.error(traceback.format_exc())
    raise
finally:
    if con is not None:
        con.close()


backup_dir = configs['dir']
stored_days = configs['days']
date = datetime.now().strftime('%Y_%m_%d')

#进入备份目录
os.chdir(backup_dir)

#删除不需要的备份
before_date = ( datetime.now() - timedelta(days=(stored_days ))).strftime('%Y_%m_%d')
if os.path.exists(before_date):
    shutil.rmtree(before_date)
    logging.info("removed mysql old backup dir {0}".format(before_date))


# 组合备份命令
backup_command = f"""/usr/bin/xtrabackup  
                     --defaults-file=/etc/my.cnf 
                     --backup 
                     --compress  
                     --compress-threads=4  
                     --user={backup_user} 
                     --password='{backup_pwd}'  
                     --target-dir={date}"""


complete = subprocess.run(shlex.split(backup_command),
                          stderr=subprocess.PIPE,
                          stdout=subprocess.PIPE,
                          encoding='utf-8')

#由于这个备份的成功失败不一定出现在out还是err当中，所以两个都记录了
output = complete.stdout +'\n'+complete.stderr
logging.info(output)

if output.find('completed OK!') > 0 :
    logging.info('backup success')
    try:
        con = pymysql.connect(config_db_host,
                              config_db_user,
                              config_db_pwd,
                              port=config_db_port,
                              cursorclass=pymysql.cursors.DictCursor)
        cursor = con.cursor()
        cursor.execute(f'update yandi.xtrabackup set date_updated = now()  where ip = "{host}"')
        con.commit()
    except Exception as e:
        traceback.print_exc()
        logging.error(traceback.format_exc())
    finally:
        if con is not None:
            con.close()
else:
    raise Exception(f'{host}备份失败，请查看/tmp/mysql_backup.log')
