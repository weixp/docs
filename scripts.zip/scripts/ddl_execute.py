import shlex
import sys
import logging
import json
import subprocess
import datetime
from utilities import get_host,get_config,query

gdid = sys.argv[1]

#获取主机ip
host = get_host()

#获取相关配置
config = get_config(host=host)

operator = config['operator']
password = config['password']

#获取主机对应的vip
#vip = sql.select(f'select vip from yandi.instance where ip="{host}" and deleted is false',host='172.16.100.36')[0]['vip']

#获取工单信息

gd = query(f'select Discribe from publish.t_process_info where id = {gdid}',host='172.16.14.253')[0]['Discribe']

#循环处理工单里面的语句
for source,sql in json.loads(gd)['executeSql'].items():
    vip = source.split('|')[2]
    db = source.split('|')[1]
    with open(f'/app/scripts/ddl_scripts/{gdid}_{vip}_ddl.sql','w') as ddl_file:
        ddl_file.write('use '+db+';\n')
        ddl_file.write(sql['ddl'])
    # 执行sql文件，整个脚本执行时间不能超过1个小时
    args = shlex.split(f"/usr/local/mysql/bin/mysql -h{vip} -u{operator}  -p'{password}' -P35972 -e 'source /app/scripts/ddl_scripts/{gdid}_{vip}_ddl.sql' ")
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8', timeout=10800)
    if result.returncode != 0:
        output = result.stderr + result.stdout
        raise Exception(output)


