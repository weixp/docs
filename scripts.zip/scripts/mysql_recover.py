#!/usr/local/bin/python3
import subprocess
import logging
import os
import time
import netifaces
import pymysql
from datetime import datetime, timedelta
import shutil
import traceback
#开启备份日志
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s  %(levelname)s  %(message)s',
                    datefmt='[%d/%b/%Y %H:%M:%S]',
                    filename='/tmp/mysql_recover.log',
                    filemode='w')

config_db_host = '172.16.100.36'
config_db_user = 'yunwei'
config_db_pwd = '7PMbpSGtFi'
config_db_port = 35972
backup_user = 'admin'
backup_pwd = 'Q@XXA8Yj'

#获取本地ip
interface = 'bond0' if 'bond0' in netifaces.interfaces() else 'eth0'
host = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['addr']


#获取配置
con = None
try:
    con = pymysql.connect(config_db_host,
                          config_db_user,
                          config_db_pwd,
                          port=config_db_port,
                          cursorclass=pymysql.cursors.DictCursor)
    cursor = con.cursor()
    cursor.execute(f'select * from yandi.xtrabackup where ip = "{host}"')
    configs = cursor.fetchone()
except Exception as e:
    traceback.print_exc()
    logging.error(traceback.format_exc())
    raise
finally:
    if con is not None:
        con.close()


backup_dir = configs['dir']
stored_days = configs['days']
source_ip = configs['source_ip']
date = datetime.now().strftime('%Y_%m_%d')
dir_name = backup_dir + '/' + datetime.now().strftime('%Y_%m_%d')

#进入恢复目录
os.chdir(backup_dir)


#获取备份文件
scp_command = 'scp -r {0}:{1} {2}'.format(source_ip, dir_name, backup_dir)

if os.path.exists(date):
    raise Exception("there already has today's backup dir,please clear it")

subprocess.run(scp_command, shell=True, check=True)
logging.info('get backup file success')

#解压备份文件
decom_outputs = subprocess.run('xtrabackup --decompress  --target-dir={0}'.format(date),
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE,
                               encoding = 'utf-8',
                               shell = True,
                               check = True)
logging.info('decompressing output')
logging.info(decom_outputs.stderr)

#恢复备份文件
pre_outputs = subprocess.run('xtrabackup --prepare  --target-dir={0}'.format(date),
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE,
                             encoding='utf-8',
                             shell=True,
                             check=True)
logging.info('prepare output......')
logging.info(pre_outputs.stderr)

#修改文件权限
subprocess.run('chown -R mysql:mysql {0}'.format(date), stderr=subprocess.PIPE, shell=True)

p = subprocess.Popen(
    "/app/mysql/dist/bin/mysqld --no-defaults --user=mysql --datadir={0}  --basedir=/app/mysql/dist".format(os.path.abspath(date)),
    stderr = subprocess.STDOUT,
    shell = True)

time.sleep(30)

try:
    recover_time = subprocess.run("/app/mysql/dist/bin/mysql -h127.0.0.1 -uweixinping -p'$X2EGrRt' -e'select max(create_time) from infra.recover_time_check' -P3306", stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf - 8',shell=True, check=True)
    # info_time = subprocess.run("cat /backup/2019_06_19/xtrabackup_info | grep end_time | cut -d'=' -f2", stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding = 'utf-8', shell = True)
    info_dir = (r'%s/xtrabackup_info' % date)
    lines = open(info_dir).readlines()
    for line in lines:
        if line.startswith('end_time'):
            info_time = line.split('=')[1].strip()
    # 将字符串时间转化为日期时间
    recover_time = datetime.strptime(recover_time.stdout.split('\n')[1].strip(), "%Y-%m-%d %H:%M:%S")
    info_time = datetime.strptime(info_time, "%Y-%m-%d %H:%M:%S")
    print('recover_time = %s' % recover_time)
    print('info_time = %s' % info_time)
    limit_up = recover_time + timedelta(minutes=1)
    limit_down = recover_time - timedelta(minutes=1)
    if info_time < limit_down or info_time > limit_up:
        raise Exception('备份时间有出入，请检查！')
except  Exception as e:
    logging.error(str(e))
    raise
finally:
    p.kill()
    p.wait()

shutil.rmtree(date)
print('delete backup recover files')
