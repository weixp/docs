import redis
from ZabbixSender import ZabbixSender, ZabbixPacket
import psutil
import  logging
import traceback
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s  %(levelname)s  %(message)s',
    datefmt='[%d/%b/%Y %H:%M:%S]',
    filename='/tmp/redis_monitor.log')

password = 'r-tj725bda9a0bae54:Dashu0701'
zabbix_server = '172.17.12.4'
host = '172.17.13.5'

need_keys = [
'uptime_in_seconds',
# Clients
'connected_clients',
'blocked_clients',
# Memory
'used_memory',
'used_memory_rss',
'mem_fragmentation_ratio',
'aof_last_write_status',
'aof_current_size',
'aof_buffer_length',
'aof_rewrite_buffer_length',
'aof_pending_bio_fsync',
'aof_delayed_fsync',
# Stats

'instantaneous_ops_per_sec',
'instantaneous_input_kbps',
'instantaneous_output_kbps',
'rejected_connections',
'sync_partial_err',
'keyspace_hits',
'keyspace_misses',
'role'
]


try:
    names = []
    for proc in psutil.process_iter():
        pinfo = proc.as_dict(attrs=['name'])
        names.append(pinfo['name'])

    server = ZabbixSender(zabbix_server, 10051)
    packet = ZabbixPacket()

    #names.append('redis-sentinel')
    #names.append('redis-server')

    if 'redis-sentinel' in names:
        packet.add(host, 'alive_sentinel', '1')
    else:
        packet.add(host, 'alive_sentinel', '0')

    if 'redis-server' in names:
        packet.add(host, 'alive_redis', '1')

        redis = redis.Redis(host, password=password)
        keys = 0
        info = redis.info()
        for key, value in info.items():
            if key.startswith('db'):
                keys = keys + value['keys']
            if key in need_keys:
                packet.add(host, key, value)

        packet.add(host,'keys',keys)
    else:
        packet.add(host, 'alive_redis', '0')

    server.send(packet)
    logging.info(server.status)
except  Exception :
    logging.error(traceback.format_exc())