import subprocess
import pymysql
import shlex

config_db_host = '172.16.100.36'
config_db_user = 'yunwei'
config_db_pwd = '7PMbpSGtFi'
config_db_port = 35972
max_id = 299182388674560000
con = pymysql.connect('172.16.100.202', config_db_user, config_db_pwd, port=config_db_port)
try:
    #更新归档标示
    with con.cursor() as cursor:
        # 设置大数据归档开始标志
        cursor.execute(f"update ecommerce1.archive_table set SIGN='true' WHERE NAME='t_taobao_record'")
        cursor.execute(f"insert into ecommerce1.archive_detail(table_name) values('t_taobao_record')")
        con.commit()

    rows=0
    for id in range(1,641):
        command = f"""/usr/local/bin/pt-archiver 
                      --source h=172.16.100.202,u={config_db_user},p={config_db_pwd},P=35972,D=ecommerce{id},t=t_taobao_record 
                      --dest h=172.17.100.36,u={config_db_user},p={config_db_pwd},P=3306,D=ecommerce,t=t_taobao_record 
                      --progress=1000000
                      --statistics
                      --where 'id<'{max_id}' ' 
                      --no-check-charset 
                      --limit=10000 
                      --txn-size=10000 
                      --bulk-insert 
                      --bulk-delete 
                      --sleep=1"""
        # 由于tidb需要保留删除的数据，所以这里需要打标记
            # 打上开始标记，并且执行pt-archiver

        complete = subprocess.run(shlex.split(command),
                                  stderr=subprocess.PIPE,
                                  stdout=subprocess.PIPE,
                                  encoding='utf-8',
                                  check=True)

        output = complete.stdout
        for line in output.split('\n'):
            if line.find('SELECT') >= 0:
                rows += int(line.split()[1])

    # 更新每个表的这次归档的归档数量
    update_row_con = pymysql.connect(config_db_host,
                                     config_db_user,
                                     config_db_pwd,
                                     port=config_db_port,
                                     cursorclass=pymysql.cursors.DictCursor)
    try:
        with update_row_con.cursor() as cursor:
            cursor.execute(f'update yandi.pt_archiver set last_archive_rows={rows} where table_name="t_taobao_record"')
    finally:
        update_row_con.commit()
        update_row_con.close()

    # 结束归档,更新归档标示
    with con.cursor() as cursor:
        cursor.execute(f"update ecommerce1.archive_table set SIGN='false' WHERE NAME='t_taobao_record'")
        cursor.execute(f"update ecommerce1.archive_detail set sign=1 where sign is null")
        con.commit()

finally:
    con.close()



#更新archive_table表和archive_detail表