
import pymysql
import time
import datetime

con = pymysql.connect('172.16.100.36','weixinping','$X2EGrRt',port=35972)
cursor = con.cursor()
for i in range(0,10000):
    num = cursor.execute('delete from zabbix.history_uint where  clock <= 1558022400 limit 100000')
    print(num)
    cursor.execute('commit')
    time.sleep(2)
    print('------------')
    print(datetime.datetime.now())
con.close()