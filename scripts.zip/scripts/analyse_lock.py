#脚本用于分析数据库当前的锁的情况
import pymysql

con_settings = {
    'host':'172.16.100.36',
    'user':'weixinping',
    'password':'$X2EGrRt',
    'port':35972,
    'cursorclass':pymysql.cursors.DictCursor
}
#获取锁的基本信息
con = pymysql.connect(**con_settings)
try:
    with con.cursor() as cursor:
        cursor.execute("""
        SELECT
        *
        FROM sys.innodb_lock_waits
        """)
        locks = cursor.fetchall()
        for lock in locks:
            print(lock)
            if lock['blocking_query'] is None:
                cursor.execute(f"""SELECT
                                        t3.THREAD_ID,
                                        SQL_TEXT
                                    FROM
                                        PERFORMANCE_SCHEMA.events_statements_current t3,
                                        PERFORMANCE_SCHEMA.threads t4
                                    WHERE
                                        t3.THREAD_ID = t4.THREAD_ID
                                    AND t4.PROCESSLIST_ID ={lock['blocking_pid']} """)
                last_query = cursor.fetchall()
                print(last_query)
                cursor.execute(f"""SELECT
                                        t3.THREAD_ID,
                                        SQL_TEXT
                                    FROM
                                        PERFORMANCE_SCHEMA .events_statements_history t3,
                                        PERFORMANCE_SCHEMA .threads t4
                                    WHERE
                                        t3.THREAD_ID = t4.THREAD_ID
                                    AND t4.PROCESSLIST_ID ={lock['blocking_pid']}
                                    ORDER BY EVENT_ID """)
                last_query = cursor.fetchall()
                print(last_query)
finally:
    con.close()

