#!/usr/local/bin/python3
from datetime import datetime
import netifaces
from email.mime.text import MIMEText
from email.utils import formataddr
import smtplib
import pymysql
config_db_host = '172.16.100.36'
config_db_user = 'yunwei'
config_db_pwd = '7PMbpSGtFi'
config_db_port = 35972
processlist = []

#获取本地ip
interface = 'bond0' if 'bond0' in netifaces.interfaces() else 'eth0'
host = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['addr']

content = ''
con = pymysql.connect('127.0.0.1',
                      config_db_user,
                      config_db_pwd,
                      port=config_db_port,
                      charset='utf8mb4',
                      cursorclass=pymysql.cursors.DictCursor)
try:
    cursor = con.cursor()
    cursor.execute('select * from information_schema.processlist where command!="sleep"')
    processlist = cursor.fetchall()
finally:
    con.close()


for process in processlist:
    if process['TIME'] >300 and process['COMMAND'] not in ('Binlog Dump','Binlog Dump GTID','Daemon','Connect') and datetime.now().hour >= 7 and datetime.now().hour <=24 :
        if process['INFO'].find('SELECT /*!40001 SQL_NO_CACHE */') >=0 and process['USER'] in ('his_data_tran'):
            continue
        content_temp= ''
        for key ,value in process.items():
            content_temp =content_temp +  key+':'+str(value)+ '\n'
        content = content + content_temp
    elif process['TIME'] >600 and process['COMMAND'] not in ('Binlog Dump','Binlog Dump GTID','Daemon','Connect') and datetime.now().hour < 7 :
        if process['INFO'].find('SELECT /*!40001 SQL_NO_CACHE */') >=0 and process['USER'] in ('his_data_tran'):
            continue
        content_temp= ''
        for key ,value in process.items():
            content_temp =content_temp +  key+':'+str(value)+ '\n'
        content = content + content_temp

if content != '':

    my_sender = 'idc@treefintech.com'
    my_pass = 'W0@Mail.ds'
    my_user = ['weixinping@treefintech.com','zhangmao@treefintech.com']
    msg = MIMEText(f'数据库主机为{host}\n'+content, 'plain', 'utf-8')
    msg['From'] = formataddr(["大树金科DBA", my_sender])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
    msg['To'] = formataddr(["大树金科DBA", ','.join(my_user)])  # 括号里的对应收件人邮箱昵称、收件人邮箱账号
    msg['Subject'] = '超时sql检查'  # 邮件的主题，也可以说是标题
    server = smtplib.SMTP_SSL("smtp.exmail.qq.com", 465)  # 发件人邮箱中的SMTP服务器，端口是465
    server.login(my_sender, my_pass)  # 括号中对应的是发件人邮箱账号、邮箱密码
    server.sendmail(my_sender, my_user, msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
    server.quit()