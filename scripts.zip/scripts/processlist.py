#!/usr/local/bin/python3
import pymysql
import sqlparse
import hashlib
#获取processlist信息

sql_need_md5 = None

class Process:

    def __init__(self,parsed_sql):
        self.parsed_sql = parsed_sql
        self.users = set()
        self.ips = set()
        self.ids = set()

sql = 'select * from information_schema.processlist'

con = pymysql.connect('172.16.14.253','weixinping','$X2EGrRt',port=35972,cursorclass=pymysql.cursors.DictCursor)
try:
    cursor = con.cursor()
    cursor.execute(sql)
    results = cursor.fetchall()
finally:
    con.close()

parsed_dic = {'None':Process('None')}

#开始解析
for process in results:
    if process['INFO'] != None:
        parse_text = ''
        sql_prase = sqlparse.parse(process['INFO'])
        parameter_place = 1
        for item in sql_prase[0].flatten():
            if (str(item.ttype) not in ('Token.Literal.String.Single', 'Token.Literal.Number.Integer')):
                parse_text = parse_text + str(item.value).upper()
            else:
                parse_text = parse_text + ':' + str(parameter_place)
                parameter_place = parameter_place + 1
        hl = hashlib.md5()
        hl.update(parse_text.encode(encoding='utf-8'))
        md5_value = hl.hexdigest()

        if md5_value not in parsed_dic.keys():
            parsed_dic[md5_value] = Process(parse_text)

        parsed_dic[md5_value].users.add(process['USER'])
        parsed_dic[md5_value].ips.add(process['HOST'])
        parsed_dic[md5_value].ids.add(process['ID'])

    else:
        parsed_dic['None'].users.add(process['USER'])
        parsed_dic['None'].ips.add(process['HOST'])
        parsed_dic['None'].ids.add(process['ID'])

for key,value in parsed_dic.items():
    print(key)
    print(f"sql template is {value.parsed_sql}")
    print(f"there are {len(value.users)} users :{value.users}")
    print(f"there are {len(value.ids)} processes")
    #print(f"they coming from {value.ips}")
    print('-------------------------')


if sql_need_md5 != None:
    for id in parsed_dic[sql_need_md5].ids:
        print(f"kill {id};")