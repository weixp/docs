i = 0

write_file =  None

with open('common_base_data.sql') as shcis:
    for line in shcis.readlines():
        if line.startswith('INSERT'):
            if i %300 == 0:
                if write_file is not None:
                    write_file.write('commit;\n')
                    write_file.close()
                write_file = open(f'new_{i}.sql','w')
            i = i + 1
            print(i)
            if i%30 == 1:
                write_file.write('START TRANSACTION;\n')
                write_file.write(line)
            elif i % 30 ==0 :
                write_file.write(line)
                write_file.write('commit;\n')
                write_file.write('select sleep(2);\n')
            else:
                write_file.write(line)