a = 0.1
b = 0.2
print(a+b)