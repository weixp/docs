#!/usr/local/bin/python3
#redis的ip
import redis
from utilities import query


redis_vip = {'172.17.13.200':'r-tj725bda9a0bae54:Dashu0701',
             '172.17.13.202':'r-tj725bda9a0bae54:Dashu0701',
             '172.17.100.206':'Dashu0701',
             '172.16.12.200':'Dashu0701'}


for vip,password in redis_vip.items():

    max_date = query(f'select max(start_time) max_date from yandi.redis_slow_log t where vip = "{vip}" ')

    if len(max_date) == 0:
        max_date = None
    else:
        max_date = max_date[0]['max_date']

    con = redis.Redis(host=vip, password=password)
    slow_logs = con.slowlog_get(128)

    for slow_log  in slow_logs:
        #计算大小

        duration = slow_log['duration']

        command = slow_log['command'].decode('utf8')

        if duration >= 100000 and max_date is None :
            print(slow_log)
            insert_sql = 'insert into yandi.redis_slow_log(vip,start_time,duration,command) values(%s,%s,%s,%s)'
            query(insert_sql,vip,slow_log['start_time'],duration,command,commit=True,escape=True)
        elif duration >= 100000 and max_date <  slow_log['start_time'] :
            print(slow_log)
            insert_sql = 'insert into yandi.redis_slow_log(vip,start_time,duration,command) values(%s,%s,%s,%s)'
            query(insert_sql, vip, slow_log['start_time'], duration, command, commit=True,escape=True)