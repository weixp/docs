import subprocess
import pymysql
import traceback
import shlex
from datetime import datetime,timedelta
import sys

db_name = sys.argv[1]

if len(sys.argv) ==3:
    sql = f'select * from yandi.pt_archiver where table_name="{sys.argv[2]}" and deleted = false'
else:
    sql = f'select * from yandi.pt_archiver where db_name="{db_name}" and deleted = false'


tables = []
config_db_host = '172.16.100.36'
config_db_user = 'yunwei'
config_db_pwd = '7PMbpSGtFi'
config_db_port = 35972


#获取归档表配置
con = pymysql.connect(config_db_host,
                      config_db_user,
                      config_db_pwd,
                      port=config_db_port,
                      cursorclass=pymysql.cursors.DictCursor)
try:
    with con.cursor() as cursor :
        cursor.execute(sql)
        tables = cursor.fetchall()
finally:
    con.close()



for table in tables:

    rows = 0
    ip =  table['ip']
    tidb = table['tidb']
    db_name = table['db_name']
    table_name = table['table_name']
    where = table['where']
    date = (datetime.now() - timedelta(days=table['days'])).strftime('%Y-%m-%d')
    print(table['db_name'], table['table_name'], date)

    con = pymysql.connect(ip,
                          config_db_user,
                          config_db_pwd,
                          port=config_db_port,
                          cursorclass=pymysql.cursors.DictCursor)
    #这里的try可以让错误发生时，继续下一个表
    try:

        #先更新每个实例的归档配置表，告诉大数据处理现在开始归档了
        with con.cursor() as cursor:
            #判断是否有该记录，有记录就更新标志，没记录就插入记录
            if cursor.execute(f"update `{tidb}`.archive_table set SIGN='true' WHERE NAME='{table_name}'") == 0:
                cursor.execute(f"insert into `{tidb}`.archive_table(name,sign) values('{table_name}','true')")

            cursor.execute(f"insert into `{tidb}`.archive_detail(table_name) values('{table_name}')")
            con.commit()

        if table['keep'] == 1:

            command = f"""
                      /usr/local/bin/pt-archiver 
                      --source h={table['ip']},u={config_db_user},p={config_db_pwd},P=35972,D={db_name},t={table_name} 
                      --dest h=172.17.100.36,u={config_db_user},p={config_db_pwd},P=3306,D={db_name},t={table_name} 
                      --progress=1000000 
                      --where '{where}<"{date}"' 
                      --limit=10000
                      --no-check-charset
                      --txn-size=10000
                      --bulk-insert 
                      --statistics
                      --bulk-delete 
                      --sleep=1
                      """
        else:
            command = f"""
                      /usr/local/bin/pt-archiver 
                      --source h={table['ip']},u={config_db_user},p={config_db_pwd},P=35972,D={db_name},t={table_name}
                      --purge 
                      --primary-key-only
                      --no-check-charset  
                      --progress=1000000 
                      --where '{where}<"{date}"' 
                      --limit=10000
                      --txn-size=10000 
                      --statistics
                      --bulk-delete 
                      --sleep=1
                      """

        complete = subprocess.run(shlex.split(command),
                                  stderr=subprocess.PIPE,
                                  stdout=subprocess.PIPE,
                                  encoding='utf-8',
                                  check=True)

        print(complete.returncode)

        #计算归档的条数
        output = complete.stdout
        for line in output.split('\n'):
            if line.find('SELECT') >= 0:
                rows = line.split()[1]

        with con.cursor() as cursor:
            cursor.execute(f"update `{tidb}`.archive_table set SIGN='false' WHERE NAME='{table_name}'")
            cursor.execute(f"update `{tidb}`.archive_detail set sign=1 where sign is null and table_name='{table_name}'")
            con.commit()

        # 更新每个表的这次归档的归档数量
        update_row_con = pymysql.connect(config_db_host,
                                         config_db_user,
                                         config_db_pwd,
                                         port=config_db_port,
                                         cursorclass=pymysql.cursors.DictCursor)
        try:
            with update_row_con.cursor() as cursor:
                cursor.execute(f'update yandi.pt_archiver set last_archive_rows={rows} where table_name="{table_name}"')
        finally:
            update_row_con.commit()
            update_row_con.close()

    except subprocess.CalledProcessError as e:
        print(e.stderr)
    except Exception :
        traceback.print_exc()
    finally:
        con.close()





#更新archive_table表和archive_detail表