import subprocess
import shlex
import sys
import pymysql

config_db_host = '172.16.100.36'
config_db_user = 'weixinping'
config_db_pwd = '$X2EGrRt'
config_db_port = 35972

con = pymysql.connect('172.16.100.19','weixinping','$X2EGrRt',port=35972)
cursor=con.cursor()

for i in range(1,961):
    num=cursor.execute(f'insert into operator.t_user_tel select * from operator{i}.t_user_tel')
    #num = cursor.execute(f'insert into operator.t_tel_net_detail(UserId,TelNum,SerialNum,BusinessType,netStartMonth,NetStartDateTime,NetType,Network,NetLocation,TotalFlow,NetDuration,TotalFee,DiscountItem,Status,CreateDate,LastUpdateDate) select UserId,TelNum,SerialNum,BusinessType,netStartMonth,NetStartDateTime,NetType,Network,NetLocation,TotalFlow,NetDuration,TotalFee,DiscountItem,Status,CreateDate,LastUpdateDate from operator{i}.t_tel_net_detail')
    print(num)
    con.commit()

con.close()