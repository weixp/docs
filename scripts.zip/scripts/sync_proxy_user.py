#!/usr/local/bin/python3
import pymysql
from utilities import get_config,get_host,send_email,query

host = get_host()
config = get_config(host=host)
operator = config['operator']
password = config['password']

mysql_users = {}


for mysql_user in query("""SELECT  `User` user , authentication_string password FROM mysql.`user` t WHERE t.`user` not in ('root','admin','mysql.session','mysql.sys')""",host=host):
    mysql_users[mysql_user['user']] = mysql_user['password']


#获取proxysql当中的用户用于比对

proxysql_users = {}

proxysql_con = pymysql.connect(host='localhost',
                               user='admin',
                               password='admin',
                               port=6032
                               )
try:
    proxysql_cursor = proxysql_con.cursor()
    proxysql_cursor.execute('select username,password from main.mysql_users')

    for proxysql_user in proxysql_cursor.fetchall():
        proxysql_users[proxysql_user[0]] = proxysql_user[1]

    #进行对比操作
    for name in mysql_users.keys():
        #如果用户不存在，那就加入proxysql
        if name not in proxysql_users.keys():
            proxysql_cursor.execute(f"insert into main.mysql_users(username,password) values('{name}','{mysql_users[name]}')")
            send_email(content=f'{host}同步了新用户{name}到proxysql',subject='proxysql用户变更')

        elif name in proxysql_users.keys() and mysql_users[name] != proxysql_users[name]:
            proxysql_cursor.execute(f"update main.mysql_users set password = '{mysql_users[name]}' where username='{name}'")
            send_email(content=f'{host}用户{name}修改了密码,正同步密码到proxysql',subject='proxysql用户变更')

    #判断proxysql当中的用户是否不在了,如果不在了，删除proxysql当中的用户
    for name in proxysql_users.keys():
        if name not in mysql_users.keys():
            proxysql_cursor.execute(f"delete from  main.mysql_users where username='{name}'")
            send_email(content=f'{host}用户{name}已经不存在,从proxysql当中删除，请注意',subject='proxysql用户变更')

    proxysql_cursor.execute('save mysql users to disk')
    proxysql_cursor.execute('load mysql users to run')

    proxysql_con.commit()

finally:
    if proxysql_con is not None:
        proxysql_con.close()