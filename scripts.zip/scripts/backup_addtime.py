#!/usr/local/bin/python3
import pymysql


need_update_host = [
    '172.16.100.201',
    '172.16.100.202',
    '172.16.100.203',
    '172.16.100.204',
    '172.17.100.203',
    '172.17.100.204',
    '172.16.100.205',
    '172.16.14.253',
    '172.17.100.37'
]

for host in need_update_host:
    print(host)
    con = pymysql.connect(host=host,
                          user='yunwei',
                          password='7PMbpSGtFi',
                          charset='utf8mb4',
                          port=35972)
    try:
        with con.cursor() as cursor:
            results = cursor.execute('update infra.recover_time_check set create_time=now()')
            print(results)
    finally:
        if con is not None:
            con.commit()
            con.close()





