import redis

"""
key_pattern = ''

#r = redis.Redis('172.17.13.202',password='r-tj725bda9a0bae54:Dashu0701',db=3)
r = redis.StrictRedis(host = "0.0.0.0",port = 6379,password = "123")

hashkey = 'rnd-ordinary-risk-clientrelationship:access-log-search-index'

i = 0

cursor,item = r.hscan(key_pattern,count=1000)
while cursor != 0:
    if len(item) >0:
        print(r.hdel(hashkey, *item))
    cursor, item = r.hscan(key_pattern,cursor=cursor ,count=1000)


cursor,item = r.sscan(key_pattern,count=1000)
while cursor != 0:
    if len(item) >0:
        print(r.srem(key_pattern, *item))
    cursor, item = r.sscan(key_pattern,cursor=cursor ,count=1000)

cursor,item = r.sscan(key_pattern,count=1000)
while cursor != 0:
    if len(item) >0:
        print(r.srem(key_pattern, *item))
    cursor, item = r.sscan(key_pattern,cursor=cursor ,count=1000)

cursor,data = r.hscan(hashkey,count=1000)

while True:
    if cursor == 0:
        exit(0)
    #print(cursor)
    print(len(data))
    if len(data) >0:
        print(r.hdel(hashkey, *data))
    cursor, data = r.hscan(hashkey,cursor=cursor ,count=1000)
"""
#先查看一共有多少个key，然后删除掉，如果scan的时候返回的都是0个数据，但是scan没有停止的话，就代表一开始就没有数据了。

key_pattern = 'USERCENTER:TOKEN:MAP:*'
r = redis.StrictRedis(host = "172.17.13.202",port = 6379,password = "r-tj725bda9a0bae54:Dashu0701")
cursor,data = r.scan(match=key_pattern,count=1000)

while cursor != 0:
    print(len(data))
    print(cursor)
    if len(data) == 0:
        continue
    if len(data) != 0:
        print(r.delete(*data))
    cursor, data = r.scan(match=key_pattern,cursor=cursor, count=1000)