import pymysql

db_tables = {
    '':''
}

con = pymysql.connect(host='172.16.14.253',user='yunwei',passwd='7PMbpSGtFi',port=35972,charset='utf8')

try:
    with con.cursor() as cursor:
        #循环处理数据库
finally:
    con.close()