import matplotlib.pyplot as plt
import numpy as np
import pymysql
#先获取数据

sql1 = '''
SELECT
	c.vip,
	round((big - SMALL) / 1024 / 1024 / 1024) GB
FROM
	(
		SELECT
			a.vip vip,
			sum(a.table_size) big
		FROM
			yandi.tables_size a
		WHERE
			date_created > '2020-04-14'
		GROUP BY
			a.vip
	) c,
	(
		SELECT
			a.vip,
			sum(a.table_size) small
		FROM
			yandi.tables_size a
		WHERE
			date_created > '2020-04-09'
		AND date_created < '2020-04-10'
		GROUP BY
			a.vip
	) d
WHERE
	c.vip = d.vip 
'''

sql2 = """
SELECT
	vip,
	round(sum(table_size) / 1024 / 1024 / 1024) MB
FROM
	yandi.tables_size t
WHERE
	t.date_created > DATE_FORMAT(now(), '%Y-%m-%d')
GROUP BY
	vip
ORDER BY
	MB DESC
"""
name_list = []
num_list = []
con = pymysql.connect('172.17.100.37','weixinping','$X2EGrRt',port=35972)
cursor = con.cursor()
cursor.execute(sql2)

results = cursor.fetchall()
print(results)
for result in results:
    name_list.append(result[0])
    num_list.append(int(result[1]))
con.close()
print(num_list)
#name_list = ['Monday', 'Tuesday', 'Friday', 'Sunday']
#num_list = [1.5, 0.6, 7.8, 6]
"""

plt.bar(range(len(num_list)), num_list,color='rgb',tick_label=name_list)
plt.xlabel('instance_ip')
plt.ylabel('size_add_last_week(GB)')
for y in num_list:
    plt.text(num_list.index(y),y,str(y), ha='center', va='bottom', fontsize=10.5)
plt.show()
"""
#实例的大小饼图
def func(pct, allvals):
    absolute = int(pct/100.*np.sum(allvals))
    return "{:.0f}%--({:d} GB)".format(pct, absolute)

fig1,ax1 = plt.subplots()
wedges, texts, autotexts = ax1.pie(num_list,labels=name_list,autopct=lambda pct: func(pct, num_list))
ax1.axis('equal')
total_size = 0
for item in num_list:
    total_size = total_size + item
plt.title(f'total_mysql_size({total_size}GB)')
plt.show()
#top10的数据库大小
#top10的表大小
#周数据增长直方图





