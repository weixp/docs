#!/usr/local/bin/python3
import sys
import pymysql
import psutil


port = 35972

user = sys.argv[1]
password = sys.argv[2]
type = sys.argv[3]
item = sys.argv[4]

#查看本地mysql是否存在
names = []
for proc in psutil.process_iter():
    try:
        pinfo = proc.as_dict(attrs=['name'])
        print(pinfo)
        names.append(pinfo['name'])
    except psutil.NoSuchProcess:
        pass
if item == 'ping' and 'mysqld' in names:
    print(1)
    exit()
elif item == 'ping' and 'mysqld' not in names :
    print(0)
    exit()
elif item != 'ping' and 'mysqld' not in names:
    print('')
    exit()


try:
    con = pymysql.connect('127.0.0.1', user, password, port=port, cursorclass=pymysql.cursors.DictCursor,charset='utf8')
    cursor = con.cursor()
    if item == 'instance_size':
        cursor.execute("select sum(DATA_LENGTH+INDEX_LENGTH) instance_size from information_schema.`TABLES` where table_schema not in ('sys') ")
        print(cursor.fetchone()['instance_size'])

    elif type == 'status':
        cursor.execute('show global status')
        results = cursor.fetchall()
        for result in results:
            if result['Variable_name'] == item:
                print(result['Value'])

    elif type == 'slave':
        cursor.execute('show slave status')
        results = cursor.fetchall()
        if len(results) == 0:
            print('')
        else:
            print(results[0][item])

    elif type == 'master':
        cursor.execute('show master status')
        results = cursor.fetchall()
        if len(results) == 0:
            print('')
        else:
            print(results[0][item])

    elif type == 'variables':
        cursor.execute('show global variables ')
        results = cursor.fetchall()
        for result in results:
            if result['Variable_name'] == item:
                print(result['Value'])

finally:
    if con is not None:
        con.close()
