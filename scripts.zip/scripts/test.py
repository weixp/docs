"""


import redis
import time
con = redis.Redis('172.17.13.5',password='r-tj725bda9a0bae54:Dashu0701')
with open('no_expire.txt','w') as expire_file:
    i = 1
    j = 1
    with open('key_name.txt') as key_names:
        for line in key_names.readlines():
            t = con.ttl(line.strip())
            if t== -1:
                j = j + 1
                print(j)
                expire_file.write(line)
            i = i + 1
            if i%10000 == 0:
                print('----------')
                time.sleep(5)
    print(j)

"""
"""select t.TABLE_SCHEMA,t.TABLE_NAME,t1.TABLE_COMMENT,t.COLUMN_NAME,t.COLUMN_COMMENT 
                            from information_schema.`COLUMNS` t,information_schema.`TABLES` t1 
                           where t.TABLE_NAME=t1.TABLE_NAME 
                             and t.TABLE_SCHEMA = t1.TABLE_SCHEMA
                             and t.TABLE_SCHEMA not in ('mysql','performance_schema','sys') 
                             and t.COLUMN_COMMENT like '%趸交%'
                             order by t.TABLE_SCHEMA,t.TABLE_NAME"""

import pymysql
import time
import datetime
ip_dic = [
    #'172.16.100.201',
    #'172.16.100.202',
    '172.16.100.203',
    '172.16.100.204',
    #'172.17.100.203',
    #'172.17.100.204',
    '172.16.100.205',
    #'172.16.14.253',
    #'172.16.100.36',
    #'172.17.100.37',
    #'10.0.10.60'
]
ip_dics = ['192.168.6.2']
for ip in ip_dic:
    #print(ip)
    con = pymysql.connect(ip,'admin','Q@XXA8Yj',port=35972)
    try:
        cursor = con.cursor()
        #cursor.execute("""select table_schema,table_name,table_rows from information_schema.`TABLES` t where TABLE_SCHEMA NOT IN (
        #                                                'sys',
        #                                                'information_schema',
        #                                                'mysql',
        #                                                'performance_schema'
        #                                            ) and t.TABLE_ROWS > 50000000 """)
        #print(cursor.execute("GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, PROCESS, FILE, REFERENCES, INDEX, ALTER, SHOW DATABASES, CREATE TEMPORARY TABLES, LOCK TABLES, EXECUTE, REPLICATION SLAVE, REPLICATION CLIENT, CREATE VIEW, SHOW VIEW, CREATE ROUTINE, ALTER ROUTINE, CREATE USER, EVENT, TRIGGER, CREATE TABLESPACE ON *.* TO 'guozepeng'@'%' WITH GRANT OPTION"))
        #print(cursor.fetchall())
        #print(cursor.fetchall())
        #for item in cursor.fetchall():
        #    print(item)
        cursor.execute(f"select '{ip}',schema_name from information_schema.SCHEMATA t where t.SCHEMA_NAME not in ('sys','mysql','information_schema','performance_schema')")
        #print(cursor.fetchall())
        for item in cursor.fetchall():
            print(item[0],item[1])
    except Exception as e:
        print(e)
    finally:
        con.close()