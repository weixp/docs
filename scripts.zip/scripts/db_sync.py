#统计生产库信息
import pymysql

user = 'yunwei'
pwd = '7PMbpSGtFi'

#获取数据库配置的vip


vips = []
vip_dbs = []
new_vip_dbs = []
con = pymysql.connect('172.16.100.36',user,pwd,port=35972)
try:
    with con.cursor() as cursor:

        cursor.execute(
            """
            SELECT DISTINCT
                (vip)
            FROM
                yandi.inventory t2
            WHERE
                t2.category = "product"
            AND type = "mysql"
            AND t2.vip NOT IN (
                '172.16.100.201',
                '172.16.100.202'
            )
            """
        )
        vips = [vip[0]  for vip in cursor.fetchall()]
        #print(vips)

        #获取vip下已经保存的数据库名
        cursor.execute("""select CONCAT(vip,'|',dbname) from yandi.db where deleted  = 0""")
        vip_dbs = [vip_db[0] for vip_db in cursor.fetchall()]
        #print(vip_dbs)

finally:
    con.close()

#开始获取数据库

for vip in vips:

    con = pymysql.connect(vip,user,pwd,port=35972)
    try:
        with con.cursor() as cursor:
            cursor.execute(
                f"""
                SELECT
                    CONCAT('{vip}','|',SCHEMA_NAME)
                FROM
                    information_schema.SCHEMATA t
                WHERE
                    t.SCHEMA_NAME NOT IN (
                        'information_schema',
                        'sys',
                        'infra',
                        'performance_schema',
                        'mysql'
                    )
                """
            )

            for item in cursor.fetchall():
                if item[0] not in vip_dbs:
                    new_vip_dbs.append((vip,item[0].split('|')[1]))
    finally:
        con.close()


con = pymysql.connect('172.16.100.36',user,pwd,port=35972)

#插入数据库
try:
    with con.cursor() as cursor:
        cursor.executemany("insert into yandi.db(vip,dbname) values(%s,%s)",new_vip_dbs)
finally:
    con.commit()
    con.close()
