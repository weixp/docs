import pymysql
from email.mime.text import MIMEText
from email.utils import formataddr
import smtplib
import traceback
#获取需要清理慢日志的数据库ip
config_db_setting = {
'host' : '172.16.100.36',
'user' : 'admin',
'password' : 'Q@XXA8Yj',
'port' : 35972,
 'cursorclass':pymysql.cursors.DictCursor
}

con = pymysql.connect(**config_db_setting)

try:
    with con.cursor() as cursor:
        cursor.execute("""
        SELECT
            ip
        FROM
            yandi.inventory t
        WHERE
            t.category = 'product'
        AND t.type = 'mysql'
""")
        ips = [ x['ip'] for x in  cursor.fetchall()]
        print(ips)
finally:
    con.close()

#清理mysql的慢日志，防止慢日志太多，导致查询太慢

for ip in ips:
    if ip in ('10.0.10.61','10.0.10.62'):
        ip = '172.17.100.100'
    con = pymysql.connect(host=ip,user='admin',password='Q@XXA8Yj',port=35972,charset='utf8mb4')

    try:
        with con.cursor() as cursor:
            cursor.execute("SET GLOBAL slow_query_log = 'OFF'")
            cursor.execute("SET sql_log_bin = 'OFF'")
            cursor.execute("RENAME TABLE mysql.slow_log TO mysql.slow_log_temp")
            cursor.execute("DELETE FROM mysql.slow_log_temp WHERE start_time < date_add(now(), interval -7 day)")
            con.commit()
            cursor.execute("RENAME TABLE mysql.slow_log_temp TO mysql.slow_log")
            cursor.execute("SET GLOBAL slow_query_log = 'ON'")
    except Exception as e:
        my_sender = 'idc@treefintech.com'  # 发件人邮箱账号
        my_pass = 'W0@Mail.ds'  # 发件人邮箱密码(当时申请smtp给的口令)
        my_user = ['dba@treefinance.com.cn']  # 收件人邮箱账号，我这边发送给自己
        msg = MIMEText(f'{ip}清理慢日志出错如下\n'+traceback.format_exc(), 'plain', 'utf-8')
        msg['From'] = formataddr(["大树金科DBA", my_sender])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
        msg['To'] = formataddr(["大树金科员工", ','.join(my_user)])  # 括号里的对应收件人邮箱昵称、收件人邮箱账号
        msg['Subject'] = '数据修改工单执行结果'  # 邮件的主题，也可以说是标题
        server = smtplib.SMTP_SSL("smtp.exmail.qq.com", 465)  # 发件人邮箱中的SMTP服务器，端口是465
        server.login(my_sender, my_pass)  # 括号中对应的是发件人邮箱账号、邮箱密码
        server.sendmail(my_sender, my_user, msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
        server.quit()
    finally:
        con.close()